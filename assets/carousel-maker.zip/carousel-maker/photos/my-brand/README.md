# Your brand photos go here

Drop 3–10 brand photos into this folder before running the setup wizard.

**Format:** JPG or PNG
**Size:** Minimum 1080px wide (square or portrait work best)
**Content:** Photos of you, your workspace, lifestyle shots — anything that represents your brand

The carousel maker picks 7 photos at random for each carousel. The more photos you add, the more variety you'll get across different carousels.

Photos work best when they have:
- Warm, natural lighting
- A clear subject (you, a workspace, a lifestyle moment)
- Some visual breathing room (not too busy or cluttered)

Once you've added your photos, return to Claude Code and say: `setup carousel maker`
