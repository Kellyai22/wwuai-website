#!/usr/bin/env python3
"""WWUAI Reel Starter engine (free version) for Claude Code and Codex.

Needs only Python, Pillow and FFmpeg. Speech model comes from npm (a package
registry every Claude chat can reach by default). No browser, no Node renderer,
no Hugging Face.

Commands:
  setup                         check/install what is needed
  prepare  WORK VIDEO           make a 720x1280 working copy
  transcribe WORK               word-timed transcript -> WORK/words.json
  storyboard WORK               real frames -> WORK/review/contact-sheet.jpg
  export WORK [--out DIR]       finished MP4 + my-reel-preferences.json
"""
import argparse, json, math, os, re, shutil, subprocess, sys, tarfile, types, zipfile
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
W, H, FPS = 720, 1280, 30
S = W / 1080  # plan coordinates are on a 1080x1920 canvas
MODEL_NPM = "transcribe2texts@1.0.6"  # carries vosk-model-small-en-us-0.15 (Apache 2.0)
MODEL_DIR_NAME = "vosk-model-small-en-us-0.15"
DEFAULT_BRAND = {"name": "Wise Women", "background": "#F8F8F8", "ink": "#8A1F2E",
                 "accent": "#E1DAD7", "caption_font": "PlusJakartaSans.ttf",
                 "heading_font": "PlayfairDisplay-Italic.ttf"}
STYLES = {
    "bright-clear": {"radius": 22, "heading_italic": False, "accent_rule": 0, "heading": "caption"},
    "warm-editorial": {"radius": 12, "heading_italic": True, "accent_rule": 6, "heading": "heading"},
}

def say(*a): print(*a, flush=True)
def read(p): return json.loads(Path(p).read_text())
def write(p, d): Path(p).write_text(json.dumps(d, indent=2, ensure_ascii=False))

def pip(*pk):
    base = [sys.executable, "-m", "pip", "install", "-q", "--disable-pip-version-check", *pk]
    for extra in (["--break-system-packages"], [], ["--user"]):
        if subprocess.run(base + extra, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
            return True
    return False

def ffmpeg():
    f = shutil.which("ffmpeg")
    if f: return f
    try:
        import imageio_ffmpeg
    except ImportError:
        pip("imageio-ffmpeg")
        import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()

def media_info(path):
    r = subprocess.run([ffmpeg(), "-hide_banner", "-i", str(path)], capture_output=True, text=True)
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", r.stderr)
    if not m: raise SystemExit(f"STOP: cannot read video {path}")
    dur = int(m[1]) * 3600 + int(m[2]) * 60 + float(m[3])
    return dur, "Audio:" in r.stderr

# ---------- setup ----------
def ensure_vosk():
    try:
        sys.modules.setdefault("srt", types.ModuleType("srt"))  # vosk imports srt only for subtitle helpers
        import vosk  # noqa
    except ImportError:
        pip("--no-deps", "vosk"); pip("cffi")
        import vosk  # noqa
    return sys.modules["vosk"]

def model_path(cache):
    cache = Path(cache); target = cache / MODEL_DIR_NAME
    if (target / "conf/model.conf").exists(): return target
    bundled = KIT / "models" / MODEL_DIR_NAME
    if (bundled / "conf/model.conf").exists(): return bundled
    cache.mkdir(parents=True, exist_ok=True)
    npm = shutil.which("npm")
    if npm:
        r = subprocess.run([npm, "pack", MODEL_NPM, "--silent"], cwd=cache, capture_output=True, text=True)
        tgz = next(cache.glob("transcribe2texts-*.tgz"), None)
    else:  # no npm: fetch tarball straight from the npm registry
        import urllib.request
        name, ver = MODEL_NPM.split("@")
        tgz = cache / f"{name}-{ver}.tgz"
        urllib.request.urlretrieve(f"https://registry.npmjs.org/{name}/-/{name}-{ver}.tgz", tgz)
    if not tgz or not tgz.exists(): raise SystemExit("STOP: could not download the speech model from npm")
    with tarfile.open(tgz) as t:
        for m in t.getmembers():
            if m.name.startswith(f"package/{MODEL_DIR_NAME}/") and m.isfile() and ".." not in m.name:
                m.name = m.name[len("package/"):]
                t.extract(m, cache, **({'filter': 'data'} if hasattr(tarfile, 'data_filter') else {}))
    tgz.unlink()
    return target

def setup(a):
    try:
        from PIL import Image  # noqa
    except ImportError:
        pip("pillow")
    say("OK pillow"); say("OK ffmpeg", ffmpeg()); ensure_vosk(); say("OK vosk")
    say("OK speech model", model_path(Path(a.cache)))
    say("READY")

# ---------- prepare ----------
def prepare(a):
    work = Path(a.work); (work / "review").mkdir(parents=True, exist_ok=True)
    src = Path(a.video)
    if src.suffix.lower() == ".zip":
        with zipfile.ZipFile(src) as z:
            vids = [n for n in z.namelist() if re.search(r"\.(mov|mp4|m4v)$", n, re.I) and not n.startswith("__MACOSX")]
            if len(vids) != 1: raise SystemExit("STOP: the ZIP must hold exactly one video")
            out = work / ("upload" + Path(vids[0]).suffix.lower())
            out.write_bytes(z.read(vids[0])); src = out
    for old in ("prepared_full.mp4", "words_full.json", "cuts.json", "words.json"):
        (work / old).unlink(missing_ok=True)
    dur, has_audio = media_info(src)
    if dur > 180: raise SystemExit("STOP: please use a clip of 3 minutes or less")
    if not has_audio: raise SystemExit("STOP: this video has no sound track")
    vf = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps={FPS},setsar=1"
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-i", str(src), "-vf", vf, "-c:v", "libx264", "-crf", "16",
                    "-preset", "veryfast", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-ar", "48000",
                    str(work / "prepared.mp4")], check=True)
    dur, _ = media_info(work / "prepared.mp4")
    saved = Path(os.environ.get("WWUAI_REEL_HOME", Path.home() / "wwuai-reel")) / "my-look.json"
    look = read(saved) if saved.exists() else {}
    if not (work / "brand.json").exists(): write(work / "brand.json", look.get("brand", DEFAULT_BRAND))
    if not (work / "plan.json").exists():
        write(work / "plan.json", {"style": look.get("style", "bright-clear"), "duration": round(dur, 3), "hook": "", "hook_end": 3,
                                   "hook_style": look.get("hook_style", "behind"), "caption_style": look.get("caption_style", "tablet"),
                                   "filter": look.get("filter", "none"),
                                   "caption_y": look.get("caption_y", 1390), "caption_size": look.get("caption_size", 80),
                                   "zoom": [], "checklists": []})
    say(f"Prepared {work/'prepared.mp4'} ({dur:.1f}s)")

# ---------- transcribe ----------
def whisper_words(work, prompt, size):
    """faster-whisper (more accurate, knows names from the prompt). Returns None if unavailable."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        if not pip("faster-whisper"): return None
        try: from faster_whisper import WhisperModel
        except ImportError: return None
    try:
        say(f"Loading Whisper {size} (first run downloads it once) ...")
        model = WhisperModel(size, device="cpu", compute_type="int8")
        wav = work / "audio16k.wav"
        subprocess.run([ffmpeg(), "-v", "error", "-y", "-i", str(work / "prepared.mp4"), "-ac", "1", "-ar", "16000", str(wav)], check=True)
        segs, _ = model.transcribe(str(wav), language="en", word_timestamps=True, vad_filter=False,
                                   initial_prompt=prompt or None, condition_on_previous_text=False)
        out = []
        for sg in segs:
            for w in sg.words or []:
                t = w.word.strip()
                if t and w.end > w.start:
                    out.append({"text": t, "start": round(w.start, 2), "end": round(w.end, 2),
                                "conf": round(w.probability, 2), "accent": False})
        wav.unlink(missing_ok=True)
        return out
    except Exception as e:
        say(f"Whisper unavailable here ({type(e).__name__}); using the backup speech model.")
        return None

def vosk_words(work, cache):
    vosk = ensure_vosk(); vosk.SetLogLevel(-1)
    model = vosk.Model(str(model_path(Path(cache))))
    raw = subprocess.run([ffmpeg(), "-v", "error", "-i", str(work / "prepared.mp4"), "-ac", "1", "-ar", "16000",
                          "-f", "s16le", "-"], capture_output=True, check=True).stdout
    rec = vosk.KaldiRecognizer(model, 16000); rec.SetWords(True); res = []
    for i in range(0, len(raw), 8000):
        if rec.AcceptWaveform(raw[i:i + 8000]): res += json.loads(rec.Result()).get("result", [])
    res += json.loads(rec.FinalResult()).get("result", [])
    return [{"text": r["word"], "start": round(r["start"], 2), "end": round(r["end"], 2),
             "conf": round(r.get("conf", 1), 2), "accent": False} for r in res]

def transcribe(a):
    work = Path(a.work)
    if (work / "prepared_full.mp4").exists():
        raise SystemExit("STOP: this video is already cut. Edit words.json directly, or run prepare again to start over.")
    words = None
    if a.engine in ("auto", "whisper"): words = whisper_words(work, a.names, a.model)
    engine = "whisper"
    if words is None:
        if a.engine == "whisper": raise SystemExit("STOP: Whisper could not run here")
        words, engine = vosk_words(work, a.cache), "vosk"
    for i, w in enumerate(words): w["i"] = i
    write(work / "words.json", words)
    say(f"[{engine}] " + " ".join(f"{i}:{w['text']}" + ("(?)" if w["conf"] < .6 else "") for i, w in enumerate(words)))
    say(f"{len(words)} words. Numbers are word positions (used by the cut step). (?) = low confidence, check it.")

# ---------- cut ----------
FILLERS = {"um", "umm", "uh", "uhh", "er", "erm", "ah", "hmm", "mm"}

def keep_ranges(words, cfg, dur):
    drop = set()
    for r in cfg.get("drop", []):
        drop.update(range(r[0], r[1] + 1))
    if cfg.get("drop_fillers", True):
        drop.update(w.get("i", i) for i, w in enumerate(words) if re.sub(r"[^a-z]", "", w["text"].lower()) in FILLERS)
    gap, pin, pout = cfg.get("gap", .45), cfg.get("pad_in", .08), cfg.get("pad_out", .18)
    groups, cur, last = [], [], None
    for i, w in enumerate(words):
        if w.get("i", i) in drop: last = None; continue
        if cur and (last is None or w["start"] - words[last]["end"] > gap):
            groups.append(cur); cur = []
        cur.append(i); last = i
    if cur: groups.append(cur)
    ranges = []
    for g in groups:
        s = max(0, words[g[0]]["start"] - pin); e = min(dur, words[g[-1]]["end"] + pout)
        if ranges and s <= ranges[-1][1] + .02: ranges[-1][1] = max(ranges[-1][1], e); ranges[-1][2] += g
        else: ranges.append([s, e, list(g)])
    return ranges

def cut(a):
    work = Path(a.work)
    full, wfull = work / "prepared_full.mp4", work / "words_full.json"
    if not full.exists():  # first cut: the current transcript is the full one
        words = read(work / "words.json")
        for i, w in enumerate(words): w.setdefault("i", i)
        src = work / "prepared.mp4"
    else:  # re-cut: carry corrections made on the cut transcript back to the full one
        words = read(wfull); cur = {w["i"]: w for w in read(work / "words.json") if "i" in w}
        kept_before = set(read(work / "kept.json")) if (work / "kept.json").exists() else set()
        merged = []
        for w in words:
            if w["i"] in kept_before and w["i"] not in cur:   # merged into the previous word or deleted
                if merged and merged[-1]["i"] in cur: merged[-1]["end"] = max(merged[-1]["end"], w["end"])
                continue
            if w["i"] in cur: w = dict(w, text=cur[w["i"]]["text"], accent=cur[w["i"]].get("accent", False))
            merged.append(w)
        words = merged
        src = full
    dur, _ = media_info(src)
    cfg_p = work / "cuts.json"
    cfg = read(cfg_p) if cfg_p.exists() else {"gap": .45, "pad_in": .08, "pad_out": .18, "drop_fillers": True, "drop": []}
    write(cfg_p, cfg)
    ranges = keep_ranges(words, cfg, dur)
    if a.plan:
        for k, (s, e, idx) in enumerate(ranges):
            say(f"keep {k+1}: {s:.2f}-{e:.2f}s  words {words[idx[0]]['i']}-{words[idx[-1]]['i']}: " + " ".join(words[i]["text"] for i in idx))
        dropped = [i for i in range(len(words)) if not any(i in r[2] for r in ranges)]
        if dropped: say("dropped words: " + ", ".join(f"{words[i]['i']}:{words[i]['text']}" for i in dropped))
        new = sum(e - s for s, e, _ in ranges)
        say(f"{dur:.1f}s -> {new:.1f}s. Add [first,last] word ranges to \"drop\" in cuts.json to remove retakes, then run cut.")
        return
    if not full.exists(): shutil.copy2(work / "prepared.mp4", full)
    # drop indices refer to positions in this list; store by original index from now on
    write(wfull, words); write(work / "kept.json", [words[i]["i"] for _, _, idx in ranges for i in idx])
    n = len(ranges); fc = []
    for k, (s, e, _) in enumerate(ranges):
        L = e - s
        fc.append(f"[0:v]trim={s:.3f}:{e:.3f},setpts=PTS-STARTPTS[v{k}]")
        fc.append(f"[0:a]atrim={s:.3f}:{e:.3f},asetpts=PTS-STARTPTS,afade=t=in:d=0.012,afade=t=out:st={max(0, L-0.015):.3f}:d=0.015[a{k}]")
    fc.append("".join(f"[v{k}][a{k}]" for k in range(n)) + f"concat=n={n}:v=1:a=1[v][a]")
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-i", str(full), "-filter_complex", ";".join(fc), "-map", "[v]", "-map", "[a]",
                    "-c:v", "libx264", "-crf", "16", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-r", str(FPS),
                    "-c:a", "aac", "-b:a", "160k", "-ar", "48000", str(work / "prepared.mp4")], check=True)
    out, off = [], 0.0
    for s, e, idx in ranges:
        for i in idx:
            w = dict(words[i]); w["start"] = round(max(0, w["start"] - s) + off, 3); w["end"] = round(min(e, w["end"]) - s + off, 3)
            out.append(w)
        off += e - s
    write(work / "words.json", out)
    newdur, _ = media_info(work / "prepared.mp4")
    plan = read(work / "plan.json"); plan["duration"] = round(newdur, 3); write(work / "plan.json", plan)
    say(f"Cut {dur:.1f}s -> {newdur:.1f}s ({n} pieces, {n-1} joins). words.json now matches the cut video.")

# ---------- drawing ----------
def hexrgb(h, a=255): return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5)) + (a,)

_SEG = None
_MASKS = {}
_VIG = None

def seg_session():
    global _SEG
    if _SEG is None:
        try:
            from rembg import new_session
        except ImportError:
            pip("rembg[cpu]"); from rembg import new_session
        _SEG = new_session("u2net_human_seg")
    return _SEG

def person_mask(img, key=None):
    """Soft mask of the person (white) for this frame. Cached per frame."""
    from PIL import Image, ImageFilter
    if key is not None and key in _MASKS: return _MASKS[key]
    from rembg import remove
    small = img.convert("RGB").resize((W // 2, H // 2))
    m = remove(small, session=seg_session(), only_mask=True)
    m = m.resize((W, H), Image.BILINEAR).filter(ImageFilter.GaussianBlur(1.2))
    if key is not None:
        if len(_MASKS) > 4: _MASKS.clear()
        _MASKS[key] = m
    return m

def vignette(strength=.35):
    import numpy as np
    global _VIG
    if _VIG is None:
        y, x = np.mgrid[0:H, 0:W]
        r = np.sqrt(((x - W / 2) / (W / 2)) ** 2 + ((y - H * .45) / (H / 2)) ** 2)
        _VIG = np.clip(r - .55, 0, 1)
    return 1 - strength * _VIG[..., None]

HOOK_STYLES = ("behind", "tablet", "typewriter")
CAPTION_STYLES = ("tablet", "bold", "editorial")
FILTERS = ("none", "cinematic", "camcorder", "film")

class Drawer:
    def __init__(self, work, plan=None, brand=None):
        from PIL import ImageFont
        self.work = Path(work)
        self.brand = brand or read(self.work / "brand.json")
        self.plan = plan or read(self.work / "plan.json")
        if self.plan.get("behind") and "hook_style" not in self.plan: self.plan["hook_style"] = "behind"
        self.style = STYLES[self.plan.get("style", "bright-clear")]
        fonts = KIT / "assets/fonts"
        def font(name, size, weight=None):
            p = self.work / "fonts" / name
            f = ImageFont.truetype(str(p if p.exists() else fonts / name), max(8, int(size)))
            if weight:
                try: f.set_variation_by_name(weight)
                except Exception: pass
            return f
        self.font = font
        self.words = read(self.work / "words.json"); self.groups = group_words(self.words)
        self.cache = {}

    def col(self, name, default="ink"):
        c = name or default
        return hexrgb(self.brand.get(c, c))

    # ---------- shared pieces ----------
    def shadowed(self, im, blur=5, alpha=110, dy=3):
        from PIL import Image, ImageFilter
        pad = blur * 3
        out = Image.new("RGBA", (im.width + 2 * pad, im.height + 2 * pad), (0, 0, 0, 0))
        sh = Image.new("RGBA", im.size, (0, 0, 0, 0)); sh.putalpha(im.getchannel("A").point(lambda v: v * alpha // 255))
        out.alpha_composite(sh, (pad, pad + dy)); out = out.filter(ImageFilter.GaussianBlur(blur))
        out.alpha_composite(im, (pad, pad))
        return out

    def tablet(self, lines, size, heading=False, italic=False, max_w=900):
        """Rounded tablet with centred text. lines = list of list of (word, accent)."""
        from PIL import Image, ImageDraw, ImageFilter
        b = self.brand; st = self.style
        fname = b["heading_font"] if heading and st["heading"] == "heading" else b["caption_font"]
        f = self.font(fname, int(size * S), None if fname == b["heading_font"] else "Bold")
        fa = self.font(b["heading_font"], int(size * 1.08 * S))
        space = f.getlength(" ")
        pad_x, pad_y, lh = int(30 * S), int(18 * S), int(size * 1.2 * S)
        widths = [sum((fa if acc else f).getlength(w) + (12 * S if acc else 0) for w, acc in ln) + space * (len(ln) - 1) for ln in lines]
        tw, th = int(max(widths) + 2 * pad_x), int(lh * len(lines) + 2 * pad_y)
        img = Image.new("RGBA", (tw + 16, th + 20), (0, 0, 0, 0))
        sh = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(sh).rounded_rectangle([8, 12, tw + 8, th + 12], int(st["radius"] * S), fill=(0, 0, 0, 50))
        img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(6)))
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([8, 6, tw + 8, th + 6], int(st["radius"] * S), fill=hexrgb(b["background"]))
        y = 6 + pad_y
        for ln, lw in zip(lines, widths):
            x = 8 + (tw - lw) / 2
            for w, acc in ln:
                ff = fa if acc else f
                ww = ff.getlength(w)
                if acc:
                    d.rounded_rectangle([x, y + lh * .12, x + ww + 12 * S, y + lh * .98], int(6 * S), fill=hexrgb(b["accent"]))
                    d.text((x + 6 * S, y + lh * .55), w, font=ff, fill=hexrgb(b["ink"]), anchor="lm")
                    x += ww + 12 * S + space
                else:
                    d.text((x, y + lh * .55), w, font=ff, fill=hexrgb(b["ink"]), anchor="lm"); x += ww + space
            y += lh
        return img

    def wrap(self, words, size, max_w, fname=None, weight="Bold", afont=None):
        b = self.brand
        f = self.font(fname or b["caption_font"], int(size * S), weight)
        fa = self.font(afont or b["heading_font"], int(size * 1.08 * S)) if afont is not False else f
        lines, cur, cw = [], [], 0
        for w, acc in words:
            ww = (fa if acc else f).getlength(w) + f.getlength(" ")
            if cur and cw + ww > max_w * S: lines.append(cur); cur, cw = [], 0
            cur.append((w, acc)); cw += ww
        if cur: lines.append(cur)
        if len(lines) == 2:  # balance two-line blocks
            flat = lines[0] + lines[1]
            def lw(ws): return sum((fa if acc else f).getlength(w) + f.getlength(" ") for w, acc in ws)
            k = min(range(1, len(flat)), key=lambda k: max(lw(flat[:k]), lw(flat[k:])))
            lines = [flat[:k], flat[k:]]
        return lines

    # ---------- caption styles ----------
    def cap_bold(self, ws, size):
        """No box. Heavy sans in the light brand colour with a dark outline; the newest word pops in the ink colour."""
        from PIL import Image, ImageDraw
        b = self.brand; size = size * 1.08
        f = self.font(b["caption_font"], size * S, "ExtraBold")
        lines = self.wrap([(w.upper() if self.plan.get("caption_case") == "upper" else w, a) for w, a in ws], size, 900, weight="ExtraBold", afont=False)
        lh = int(size * 1.15 * S); stroke = max(2, int(5 * S)); space = f.getlength(" ")
        widths = [sum(f.getlength(w) for w, _ in ln) + space * (len(ln) - 1) for ln in lines]
        im = Image.new("RGBA", (int(max(widths) + 4 * stroke + 4), lh * len(lines) + 4 * stroke), (0, 0, 0, 0))
        d = ImageDraw.Draw(im); y = 2 * stroke; total = sum(len(l) for l in lines); k = 0
        for ln, lw in zip(lines, widths):
            x = (im.width - lw) / 2
            for w, acc in ln:
                k += 1; newest = k == total
                fill, line = (hexrgb(b["ink"]), hexrgb(b["background"])) if (newest or acc) else (hexrgb(b["background"]), hexrgb(b["ink"]))
                d.text((x, y + lh * .5), w, font=f, fill=fill, anchor="lm", stroke_width=stroke, stroke_fill=line)
                x += f.getlength(w) + space
            y += lh
        return self.shadowed(im, 6, 90, 4)

    def cap_editorial(self, ws, size):
        """No box. Elegant serif italic in the light brand colour, soft shadow, key words underlined in the accent."""
        from PIL import Image, ImageDraw
        b = self.brand; size = size * 1.15
        f = self.font(b["heading_font"], size * S)
        lines = self.wrap(ws, size, 880, fname=b["heading_font"], weight=None, afont=False)
        lh = int(size * 1.18 * S); space = f.getlength(" ")
        widths = [sum(f.getlength(w) for w, _ in ln) + space * (len(ln) - 1) for ln in lines]
        im = Image.new("RGBA", (int(max(widths) + 20), lh * len(lines) + 20), (0, 0, 0, 0))
        d = ImageDraw.Draw(im); y = 10
        for ln, lw in zip(lines, widths):
            x = (im.width - lw) / 2
            for w, acc in ln:
                ww = f.getlength(w)
                d.text((x, y + lh * .5), w, font=f, fill=hexrgb(b["background"]), anchor="lm")
                if acc:
                    d.rounded_rectangle([x, y + lh * .86, x + ww, y + lh * .86 + max(3, int(6 * S))], 3, fill=hexrgb(b.get("underline", b["accent"])))
                x += ww + space
            y += lh
        return self.shadowed(im, 7, 150, 3)

    # ---------- hook styles ----------
    def hook_window(self):
        p = self.plan
        if not p.get("hook") and not self.hook_word(): return None
        return p.get("hook_start", 0), p.get("hook_end", 3)

    def hook_word(self):
        p = self.plan
        return p.get("hook_word") or (p.get("behind") or {}).get("text")

    def typewriter(self, text, n, caret):
        from PIL import Image, ImageDraw, ImageFilter
        b = self.brand; size = 62
        f = self.font(b.get("type_font", "CourierPrime-Bold.ttf"), size * S)
        full = self.wrap([(w, False) for w in text.split()], size, 820, fname=b.get("type_font", "CourierPrime-Bold.ttf"), weight=None, afont=False)
        lines_full = [" ".join(w for w, _ in ln) for ln in full]
        lh = int(size * 1.3 * S); pad_x, pad_y = int(32 * S), int(22 * S)
        tw = int(max(f.getlength(l) for l in lines_full) + 2 * pad_x + f.getlength("|")); th = lh * len(lines_full) + 2 * pad_y
        img = Image.new("RGBA", (tw + 16, th + 20), (0, 0, 0, 0))
        sh = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(sh).rounded_rectangle([8, 12, tw + 8, th + 12], int(14 * S), fill=(0, 0, 0, 50))
        img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(6)))
        d = ImageDraw.Draw(img); d.rounded_rectangle([8, 6, tw + 8, th + 6], int(14 * S), fill=hexrgb(b["background"]))
        left, y, done = 8 + pad_x, 6 + pad_y, 0
        for li, line in enumerate(lines_full):
            part = line[:max(0, n - done)]; done += len(line) + 1
            d.text((left, y + lh * .5), part, font=f, fill=hexrgb(b["ink"]), anchor="lm")
            if caret and (n < done or li == len(lines_full) - 1) and (n >= done - len(line) - 1):
                cx = left + f.getlength(part) + 2
                d.rectangle([cx, y + lh * .2, cx + max(3, int(5 * S)), y + lh * .82], fill=hexrgb(b["ink"]))
                caret = False
            y += lh
        return img

    def behind_text_img(self, scale=1.0):
        from PIL import Image, ImageDraw
        txt = self.hook_word(); fname = self.plan.get("hook_word_font", self.brand["heading_font"])
        size = int(400 * S); f = self.font(fname, size)
        while f.getlength(txt) > W * .94 and size > 40:
            size -= 6; f = self.font(fname, size)
        size = min(size, int(H * .2)); f = self.font(fname, int(size * scale))
        bb = f.getbbox(txt, anchor="mm"); w, h = bb[2] - bb[0] + 20, bb[3] - bb[1] + 20
        im = Image.new("RGBA", (int(w), int(h)), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((w / 2, h / 2), txt, font=f, fill=self.col(self.plan.get("hook_word_color"), "ink"), anchor="mm")
        return im

    def behind_place(self, img, key=None):
        """Pick the text row with the most visible background (top half). Returns y centre or None."""
        import numpy as np
        if "y_auto" in self.cache: return self.cache["y_auto"]
        if self.plan.get("hook_word_y") is not None:
            self.cache["y_auto"] = self.plan["hook_word_y"] * S; return self.cache["y_auto"]
        hs, he = self.hook_window()
        samples = [hs + .3, (hs + he) / 2, max(hs + .3, he - .3)]
        try: frames = frames_at(self.work, samples)
        except Exception: frames = [img]
        m = np.mean([np.array(person_mask(f)) > 128 for f in frames], axis=0)  # where the person usually is
        th = self.behind_text_img().height
        best, by = 0, None
        for yc in range(int(H * .055 + th / 2), int(H * .5), 8):
            free = 1 - m[max(0, yc - th // 3): yc + th // 3].mean()
            score = free - (yc / H) * .15
            if score > best: best, by = score, yc
        free_at = 1 - m[max(0, by - th // 3): by + th // 3].mean() if by else 0
        self.cache["y_auto"] = by if (by and free_at >= .35) else None
        self.cache["free"] = round(float(free_at), 2)
        return self.cache["y_auto"]

    def hook_behind_on(self, t):
        win = self.hook_window()
        return (self.plan.get("hook_style") == "behind" and self.hook_word() and win and win[0] <= t < win[1]
                and self.cache.get("y_auto", 0) is not None)

    def behind(self, img, raw, t, key):
        if not self.hook_behind_on(t): return img
        y = self.behind_place(raw, key)
        if y is None: return img
        s0, e0 = self.hook_window()
        a = max(0, min(1, (t - s0) / .25, (e0 - t) / .25))
        sc = 1.06 - .06 * min(1, (t - s0) / .6)
        k = ("behindtxt", round(sc, 3))
        if k not in self.cache: self.cache[k] = self.behind_text_img(sc)
        tx = self.cache[k]
        if a < 1:
            tx = tx.copy(); tx.putalpha(tx.getchannel("A").point(lambda v: int(v * a)))
        out = img.copy(); out.alpha_composite(tx, (int(W / 2 - tx.width / 2), int(y - tx.height / 2)))
        person = img.copy(); person.putalpha(person_mask(raw, key))
        out.alpha_composite(person)
        return out

    # ---------- layers ----------
    def layers(self, t):
        """Return list of (key, builder, x_center, y_top, alpha) for time t."""
        p = self.plan; out = []
        win = self.hook_window()
        if win and win[0] <= t < win[1] and not self.hook_behind_on(t):
            hs, he = win; a = min(1, (t - hs) / .3, (he - t) / .25)
            text = p.get("hook") or self.hook_word()
            if p.get("hook_style") == "typewriter":
                rate = max(14, len(text) / max(.6, (he - hs) * .55))
                n = max(0, int((t - hs - .15) * rate)); caret = int(t * 2.2) % 2 == 0 or n < len(text)
                out.append((("type", n, caret), lambda text=text, n=n, caret=caret: self.typewriter(text, n, caret), W / 2, 150 * S, min(1, (he - t) / .25)))
            else:
                words = [(w, False) for w in text.split()]
                out.append((("hook",), lambda: self.tablet(self.wrap(words, 74, 860), 74, heading=True), W / 2, 150 * S, a))
        cs = p.get("caption_style", "tablet"); size = p.get("caption_size", 80)
        for gi, g in enumerate(self.groups):
            if g["words"][0]["start"] <= t < g["end"]:
                n = sum(1 for w in g["words"] if w["start"] <= t)
                ws = [(w["text"], w.get("accent", False)) for w in g["words"][:n]]
                if cs == "bold": build = lambda ws=ws: self.cap_bold(ws, size)
                elif cs == "editorial": build = lambda ws=ws: self.cap_editorial(ws, size)
                else: build = lambda ws=ws: self.tablet(self.wrap(ws, size, 860), size)
                out.append((("cap", cs, gi, n), build, W / 2, p.get("caption_y", 1390) * S, 1))
        for ci, c in enumerate(p.get("checklists", [])):
            if c["start"] <= t < c["end"]:
                times = c.get("item_times") or [c["start"] + .3 + j * .4 for j in range(len(c["items"]))]
                n = sum(1 for tt in times if tt <= t)
                a = min(1, (t - c["start"]) / .3, (c["end"] - t) / .25)
                out.append((("list", ci, n), lambda c=c, n=n: self.checklist(c, n), c.get("side", "left"), c.get("y", 230) * S, a))
        return out

    def checklist(self, c, n):
        from PIL import Image, ImageDraw, ImageFilter
        b = self.brand; st = self.style
        ft = self.font(b["caption_font"], int(52 * S), "Bold")
        fr = self.font(b["caption_font"], int(46 * S), "SemiBold")
        pad = int(28 * S); row = int(64 * S)
        wbox = int(max([ft.getlength(c["title"])] + [fr.getlength(t) + 50 * S for t in c["items"]]) + 2 * pad)
        hbox = pad * 2 + int(64 * S) + row * len(c["items"])
        img = Image.new("RGBA", (wbox + 16, hbox + 20), (0, 0, 0, 0))
        sh = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(sh).rounded_rectangle([8, 12, wbox + 8, hbox + 12], int(st["radius"] * S), fill=(0, 0, 0, 50))
        img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(6)))
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([8, 6, wbox + 8, hbox + 6], int(st["radius"] * S), fill=hexrgb(b["background"]), outline=hexrgb(b["accent"]), width=max(2, int(3 * S)))
        d.text((8 + pad, 6 + pad), c["title"], font=ft, fill=hexrgb(b["ink"]))
        y = 6 + pad + int(64 * S); r = int(18 * S)
        for j, item in enumerate(c["items"]):
            cx, cy = 8 + pad + r, y + row // 2
            if j < n:
                d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=hexrgb(b["accent"]))
                d.line([(cx - r * .45, cy), (cx - r * .1, cy + r * .4), (cx + r * .5, cy - r * .4)], fill=hexrgb(b["ink"]), width=max(2, int(4 * S)), joint="curve")
                d.text((cx + r + int(16 * S), cy), item, font=fr, fill=hexrgb(b["ink"]), anchor="lm")
            else:
                d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=hexrgb(b["accent"]), width=max(2, int(3 * S)))
            y += row
        return img

    def zoom(self, t):
        for z in self.plan.get("zoom", []):
            s, e, k = z["start"], z["end"], z.get("scale", 1.06)
            if s <= t < e:
                u = min(1, (t - s) / .45, (e - t) / .45)
                u = .5 - .5 * math.cos(math.pi * max(0, u))
                return 1 + (k - 1) * u
        return 1

    # ---------- filters ----------
    def apply_filter(self, img, t, key):
        import numpy as np
        from PIL import Image, ImageFilter
        flt = self.plan.get("filter", "none")
        if flt == "cinematic":
            # Portrait-mode look: background melts into soft bokeh, person stays sharp, gentle warm grade.
            m = person_mask(img, key).filter(ImageFilter.GaussianBlur(3))
            small = img.convert("RGB").resize((W // 8, H // 8), Image.BILINEAR).filter(ImageFilter.GaussianBlur(3.5))
            bg = small.resize((W, H), Image.BICUBIC)
            out = Image.composite(img.convert("RGB"), bg, m)
            a = np.asarray(out).astype(np.float32)
            a = (a - 128) * 1.06 + 128
            a[..., 0] *= 1.03; a[..., 2] *= .96
            a *= vignette(.30)
            return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))
        if flt == "camcorder":
            # Home-video look: softer picture, faded warm-green colour, scanlines, colour fringing, noise.
            soft = img.convert("RGB").resize((W // 2, H // 2), Image.BILINEAR).resize((W, H), Image.BILINEAR)
            a = np.asarray(soft).astype(np.float32)
            g = a.mean(axis=2, keepdims=True); a = g + (a - g) * .72
            a = a * .9 + 22; a[..., 0] += 10; a[..., 1] += 6; a[..., 2] -= 8
            a[..., 0] = np.roll(a[..., 0], 3, axis=1); a[..., 2] = np.roll(a[..., 2], -3, axis=1)
            a[::3] *= .9
            rng = np.random.default_rng(int(t * FPS)); a += rng.normal(0, 7, (H, W, 1))
            a *= vignette(.38)
            return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))
        if flt == "film":
            # Warm film: lifted blacks, golden tone, soft glow on highlights, fine grain.
            base = img.convert("RGB"); a = np.asarray(base).astype(np.float32)
            glow = np.asarray(base.resize((W // 4, H // 4)).filter(ImageFilter.GaussianBlur(6)).resize((W, H))).astype(np.float32)
            glow = np.clip(glow - 130, 0, 255) * .8
            a = 255 - (255 - a) * (255 - glow) / 255
            g = a.mean(axis=2, keepdims=True); a = g + (a - g) * .85
            a = a * .84 + 28; a[..., 0] *= 1.10; a[..., 1] *= 1.02; a[..., 2] *= .80
            rng = np.random.default_rng(int(t * FPS)); a += rng.normal(0, 9, (H, W, 1))
            a *= vignette(.32)
            return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))
        return img

    def camcorder_osd(self, img, t):
        from PIL import ImageDraw
        if self.plan.get("filter") != "camcorder" or self.plan.get("camcorder_text") is False: return img
        d = ImageDraw.Draw(img); f = self.font("CourierPrime-Bold.ttf", 54 * S); y = int(H * .035)
        if int(t * 1.6) % 2 == 0:
            d.ellipse([int(48 * S), y + int(8 * S), int(86 * S), y + int(46 * S)], fill=(220, 40, 40, 255))
        d.text((int(100 * S), y), "REC", font=f, fill=(255, 255, 255, 235), stroke_width=2, stroke_fill=(0, 0, 0, 120))
        stamp = self.plan.get("camcorder_date", "OCT 21 2026")
        d.text((W - int(48 * S), y), stamp, font=f, fill=(255, 255, 255, 235), anchor="ra", stroke_width=2, stroke_fill=(0, 0, 0, 120))
        tc = f"{int(t // 60):02d}:{int(t % 60):02d}:{int(t * FPS % FPS):02d}"
        d.text((W - int(48 * S), y + int(66 * S)), tc, font=f, fill=(255, 255, 255, 215), anchor="ra", stroke_width=2, stroke_fill=(0, 0, 0, 120))
        return img

    def frame(self, img, t, key=None):
        from PIL import Image
        z = self.zoom(t)
        if z > 1.001:
            cw, ch = W / z, H / z; cx, cy = W / 2, H * .38
            box = (cx - cw / 2, cy - ch * .38, cx + cw / 2, cy + ch * .62)
            img = img.resize((W, H), Image.BICUBIC, box=box); key = None
        raw = img.convert("RGB")
        img = self.apply_filter(raw, t, key).convert("RGBA")
        img = self.behind(img, raw, t, key)
        img = self.camcorder_osd(img, t)
        for k, build, xc, y, a in self.layers(t):
            if k not in self.cache: self.cache[k] = build()
            ov = self.cache[k]
            if a < 1:
                ov = ov.copy(); ov.putalpha(ov.getchannel("A").point(lambda v: int(v * max(0, a))))
            if xc == "left": x = int(50 * S)
            elif xc == "right": x = int(W - ov.width - 50 * S)
            elif xc == "center": x = int(W / 2 - ov.width / 2)
            else: x = int(xc - ov.width / 2)
            img.alpha_composite(ov, (x, int(y)))
        return img.convert("RGB")

class Look:
    """The whole edit, including optional 'segments' that switch hook, captions, filter or colours mid-video."""
    def __init__(self, work):
        self.work = Path(work); self.base = Drawer(work)
        self.plan, self.brand, self.groups = self.base.plan, self.base.brand, self.base.groups
        self.segs = self.plan.get("segments", []); self.d = {}; self.font = self.base.font

    def drawer(self, t):
        for i, s in enumerate(self.segs):
            if s["start"] <= t < s["end"]:
                if i not in self.d:
                    plan = {k: v for k, v in self.plan.items() if k != "segments"}
                    plan.update({k: v for k, v in s.items() if k not in ("start", "end", "brand")})
                    brand = dict(self.brand); brand.update(s.get("brand", {}))
                    self.d[i] = Drawer(self.work, plan, brand)
                return self.d[i]
        return self.base

    def frame(self, img, t, key=None):
        return self.drawer(t).frame(img, t, key)

def check_behind(a):
    work = Path(a.work); lk = Look(work)
    targets = [(lk.base, lk.plan)] + [(None, s) for s in lk.segs if s.get("hook_style") == "behind"]
    found = False
    for dr, cfg in targets:
        t0 = cfg.get("hook_start", 0); t1 = cfg.get("hook_end", lk.plan.get("hook_end", 3))
        if cfg is not lk.plan: t0, t1 = cfg.get("hook_start", cfg["start"]), cfg.get("hook_end", cfg["end"])
        dr = dr or lk.drawer((t0 + t1) / 2)
        if dr.plan.get("hook_style") != "behind" or not dr.hook_word(): continue
        found = True; t = (t0 + t1) / 2
        img = frames_at(work, [t])[0]
        y = dr.behind_place(img.convert("RGBA"))
        if y is None:
            say(f"[{t:.1f}s] NOT ENOUGH SPACE for '{dr.hook_word()}': only {dr.cache['free']:.0%} of the background shows around the head. Use hook_style tablet or typewriter, or a shorter word.")
        else:
            p = work / "review"; p.mkdir(exist_ok=True); out = p / f"behind-check-{t:.1f}.jpg"
            dr.frame(img, t).save(out); say(f"[{t:.1f}s] FITS '{dr.hook_word()}' ({dr.cache['free']:.0%} background visible). Preview: {out}")
    if not found: raise SystemExit("No hook_style 'behind' with a hook_word in plan.json")

def samples(a):
    """A sheet of every hook, caption style and filter, drawn on the person's own clip."""
    import copy
    from PIL import Image, ImageDraw
    work = Path(a.work); base = Drawer(work); p = copy.deepcopy(base.plan); p.pop("segments", None)
    dur, _ = media_info(work / "prepared.mp4")
    word = p.get("hook_word") or (p.get("hook") or "Hello").split()[0]
    p.setdefault("hook", "Your hook goes here"); p["hook_word"] = word
    p["hook_end"] = p.get("hook_end", 3); p["hook_start"] = 0
    gt = next((g["words"][-1]["start"] + .05 for g in base.groups if g["words"][0]["start"] > p["hook_end"]), min(dur - .1, 5))
    ft = min(dur - .1, max(gt + 2, dur * .6))
    rows = [("Hook", 1.2, [("Big word", dict(hook_style="behind")), ("Tablet", dict(hook_style="tablet")), ("Typewriter", dict(hook_style="typewriter"))]),
            ("Captions", gt, [("Tablet", dict(caption_style="tablet")), ("Bold", dict(caption_style="bold")), ("Editorial", dict(caption_style="editorial"))]),
            ("Filter", ft, [("Cinematic", dict(filter="cinematic")), ("Camcorder", dict(filter="camcorder")), ("Warm film", dict(filter="film"))])]
    tw, th = 300, 533
    sheet = Image.new("RGB", (3 * (tw + 14) + 14, len(rows) * (th + 60) + 14), hexrgb(base.brand["background"])[:3])
    d = ImageDraw.Draw(sheet); f = base.font(base.brand["caption_font"], 26, "Bold")
    for r, (name, t, opts) in enumerate(rows):
        frame = frames_at(work, [t])[0]
        for c, (label, over) in enumerate(opts):
            q = copy.deepcopy(p); q.update(over)
            if name != "Filter": q["filter"] = "none"
            dr = Drawer(work, q, dict(base.brand))
            im = dr.frame(frame, 2.0 if label == "Typewriter" else t)
            x, y = 14 + c * (tw + 14), 14 + r * (th + 60)
            note = " (needs headroom)" if label == "Big word" and dr.cache.get("y_auto", 0) is None else ""
            d.text((x, y), f"{name}: {label}{note}", font=f, fill=hexrgb(base.brand["ink"]))
            sheet.paste(im.resize((tw, th)), (x, y + 40))
    out = work / "review" / "my-options.jpg"; out.parent.mkdir(exist_ok=True); sheet.save(out, quality=88)
    say(f"Options sheet: {out}")

LOOK_KEYS = ("style", "hook_style", "caption_style", "filter", "caption_size", "caption_y", "hook_word_color")
LOOK_DEFAULTS = {"style": "bright-clear", "hook_style": "behind", "caption_style": "tablet", "filter": "none",
                 "caption_size": 80, "caption_y": 1390, "hook_word_color": "ink"}

def looks_dir():
    d = Path(os.environ.get("WWUAI_REEL_HOME", Path.home() / "wwuai-reel")) / "looks"; d.mkdir(parents=True, exist_ok=True); return d

def slug(name): return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "look"

def save_look(a):
    """Save the current project's look under a name (a 'stamp' in their collection)."""
    work = Path(a.work); plan = read(work / "plan.json"); brand = read(work / "brand.json")
    look = {"name": a.name, "brand": brand, **{k: plan.get(k, LOOK_DEFAULTS[k]) for k in LOOK_KEYS}}
    old = looks_dir() / f"{slug(a.name)}.json"
    if old.exists() and "names" in read(old): look["names"] = read(old)["names"]
    write(old, look); say(f"Saved look '{a.name}'.")
    if a.default:
        home = looks_dir().parent; mine = read(home / "my-look.json") if (home / "my-look.json").exists() else {}
        mine.update({k: v for k, v in look.items() if k != "name"}); mine["look_name"] = a.name
        write(home / "my-look.json", mine); say(f"'{a.name}' is now the look every new reel starts with.")

def use_look(a):
    work = Path(a.work); f = looks_dir() / f"{slug(a.name)}.json"
    if not f.exists():
        names = [read(x)["name"] for x in sorted(looks_dir().glob("*.json"))]
        raise SystemExit(f"No look called '{a.name}'. Saved looks: {', '.join(names) or 'none yet'}")
    look = read(f); plan = read(work / "plan.json")
    plan.update({k: look.get(k, LOOK_DEFAULTS[k]) for k in LOOK_KEYS}); write(work / "plan.json", plan)
    write(work / "brand.json", look["brand"]); say(f"Using look '{look['name']}'. Export again to see it.")

def list_looks(a):
    looks = [read(x) for x in sorted(looks_dir().glob("*.json"))]
    if not looks: say("No saved looks yet."); return
    for l in looks:
        say(f"- {l['name']}: hook {l.get('hook_style','behind')}, captions {l.get('caption_style','tablet')}, filter {l.get('filter','none')}, colours {l['brand'].get('background')} / {l['brand'].get('ink')} / {l['brand'].get('accent')}")

def looks_sheet(a):
    """One picture showing every saved look on this clip: their style menu."""
    import copy
    from PIL import Image, ImageDraw
    work = Path(a.work); looks = [read(x) for x in sorted(looks_dir().glob("*.json"))]
    if not looks: raise SystemExit("No saved looks yet.")
    base = Drawer(work); p = copy.deepcopy(base.plan); p.pop("segments", None)
    dur, _ = media_info(work / "prepared.mp4")
    t = next((g["words"][-1]["start"] + .05 for g in base.groups if g["words"][0]["start"] > p.get("hook_end", 3)), min(dur - .1, 5))
    frame = frames_at(work, [t])[0]; tw, th = 300, 533; cols = min(3, len(looks)); rows = math.ceil(len(looks) / cols)
    sheet = Image.new("RGB", (cols * (tw + 14) + 14, rows * (th + 60) + 14), hexrgb(base.brand["background"])[:3])
    d = ImageDraw.Draw(sheet); f = base.font(base.brand["caption_font"], 26, "Bold")
    for k, l in enumerate(looks):
        q = copy.deepcopy(p); q.update({x: l.get(x, LOOK_DEFAULTS[x]) for x in LOOK_KEYS})
        im = Drawer(work, q, dict(l["brand"])).frame(frame, t)
        x, y = 14 + (k % cols) * (tw + 14), 14 + (k // cols) * (th + 60)
        d.text((x, y), l["name"], font=f, fill=hexrgb(base.brand["ink"])); sheet.paste(im.resize((tw, th)), (x, y + 40))
    out = work / "review" / "my-looks.jpg"; out.parent.mkdir(exist_ok=True); sheet.save(out, quality=88); say(f"Style menu: {out}")

def group_words(words):
    groups, cur = [], []
    for i, w in enumerate(words):
        if cur and (len(cur) >= 5 or (len(cur) >= 3 and w["start"] - cur[-1]["end"] > .25) or w["start"] - cur[-1]["end"] > .6):
            groups.append(cur); cur = []
        cur.append(w)
        if re.search(r"[.?!]$", w["text"]) and len(cur) >= 2: groups.append(cur); cur = []
    if cur: groups.append(cur)
    out = []
    for i, g in enumerate(groups):
        nxt = groups[i + 1][0]["start"] if i + 1 < len(groups) else g[-1]["end"] + .6
        out.append({"words": g, "end": min(nxt, g[-1]["end"] + .6)})
    return out

def frames_at(work, times):
    from PIL import Image
    out = []
    for t in times:
        raw = subprocess.run([ffmpeg(), "-v", "error", "-ss", f"{t:.3f}", "-i", str(Path(work) / "prepared.mp4"), "-frames:v", "1",
                              "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True, check=True).stdout
        out.append(Image.frombytes("RGB", (W, H), raw[:W * H * 3]))
    return out

# ---------- storyboard ----------
def storyboard(a):
    from PIL import Image, ImageDraw
    work = Path(a.work); dr = Look(work); p = dr.plan; beats = []
    if p.get("hook"): beats.append((min(1.2, p["hook_end"] - .3), "Hook", p["hook"]))
    for g in dr.groups:
        t = max(g["words"][-1]["start"] + .05, g["words"][0]["start"])
        if p.get("hook") and t < p["hook_end"]: t = max(t, 0)
        beats.append((t, "Captions", " ".join(w["text"] for w in g["words"])))
    for c in p.get("checklists", []):
        beats.append((c["end"] - .4, "Checklist", f'{c["title"]}: ' + " / ".join(c["items"])))
    for z in p.get("zoom", []):
        beats.append(((z["start"] + z["end"]) / 2, "Zoom", f'gentle push in to {z.get("scale",1.06)}x, {z["start"]:.1f}s to {z["end"]:.1f}s'))
    beats.sort(key=lambda b: b[0])
    imgs = [dr.frame(f, t) for f, (t, _, _) in zip(frames_at(work, [b[0] for b in beats]), beats)]
    rev = work / "review"; rev.mkdir(exist_ok=True)
    for old in rev.glob("*.jpg"): old.unlink()
    tw, th, cols = 270, 480, 4
    per = 8
    sheets = []
    for si in range(0, len(imgs), per):
        chunk = list(zip(range(si + 1, si + 1 + per), imgs[si:si + per], beats[si:si + per]))
        rows = math.ceil(len(chunk) / cols)
        sheet = Image.new("RGB", (cols * (tw + 12) + 12, rows * (th + 12) + 12), hexrgb(dr.brand["background"])[:3])
        d = ImageDraw.Draw(sheet); fnt = dr.font(dr.brand["caption_font"], 30, "Bold")
        for k, (num, im, (t, kind, line)) in enumerate(chunk):
            x, y = 12 + (k % cols) * (tw + 12), 12 + (k // cols) * (th + 12)
            sheet.paste(im.resize((tw, th)), (x, y))
            d.rounded_rectangle([x + 8, y + 8, x + 66, y + 50], 12, fill=hexrgb(dr.brand["ink"]))
            d.text((x + 37, y + 29), str(num), font=fnt, fill=hexrgb(dr.brand["background"]), anchor="mm")
            d.text((x + tw - 10, y + th - 12), f"{t:.1f}s", font=dr.font(dr.brand["caption_font"], 22, "Bold"), fill=(255, 255, 255), anchor="rb", stroke_width=2, stroke_fill=(0, 0, 0))
        path = rev / f"contact-sheet-{len(sheets)+1}.jpg"; sheet.save(path, quality=88); sheets.append(path)
    lines = [f"{i}. {t:.1f}s  {kind}: {line}" for i, (t, kind, line) in enumerate(beats, 1)]
    (rev / "storyboard.md").write_text("\n".join(lines))
    write(rev / "revision.json", {"revision": fingerprint(work)})
    say("\n".join(lines)); say("Sheets:", *sheets)

def fingerprint(work):
    import hashlib
    h = hashlib.sha256()
    for n in ["brand.json", "plan.json", "words.json"]: h.update((Path(work) / n).read_bytes())
    return h.hexdigest()[:16]

# ---------- export ----------
def export(a, preview=False):
    work = Path(a.work)
    dr = Look(work); dur, _ = media_info(work / "prepared.mp4")
    kbps = max(1500, min(6000, int(26 * 8000 / max(dur, 1)) - 170))  # keeps the file under ~28 MB (chat download limit is 30 MB)
    out = work / ("preview.mp4" if preview else "finished-reel.mp4")
    dec = subprocess.Popen([ffmpeg(), "-v", "error", "-i", str(work / "prepared.mp4"), "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE)
    enc = subprocess.Popen([ffmpeg(), "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                            "-i", str(work / "prepared.mp4"), "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium",
                            "-b:v", f"{kbps}k", "-maxrate", f"{int(kbps*1.3)}k", "-bufsize", f"{kbps*2}k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                            "-shortest", "-movflags", "+faststart", str(out)], stdin=subprocess.PIPE)
    from PIL import Image
    i = 0
    while True:
        raw = dec.stdout.read(W * H * 3)
        if len(raw) < W * H * 3: break
        enc.stdin.write(dr.frame(Image.frombytes("RGB", (W, H), raw), i / FPS, i // 2).tobytes()); i += 1  # one cut-out per two frames
    enc.stdin.close(); enc.wait(); dec.wait()
    odur, audio = media_info(out); mb = out.stat().st_size / 1e6
    if not audio: raise SystemExit("STOP: export has no audio")
    if abs(odur - dur) > .3: raise SystemExit("STOP: export length does not match the clip")
    if mb > 29.5: raise SystemExit(f"STOP: export is {mb:.1f} MB, over the chat download limit")
    write(work / "my-reel-preferences.json", {"brand": dr.brand, "style": dr.plan["style"],
          "caption_size": dr.plan.get("caption_size", 80), "caption_y": dr.plan.get("caption_y", 1390)})
    if getattr(a, "out", None):
        o = Path(a.out); o.mkdir(parents=True, exist_ok=True)
        shutil.copy2(out, o / out.name); shutil.copy2(work / "my-reel-preferences.json", o / "my-reel-preferences.json")
        out = o / out.name
    say(f"Finished {out} ({odur:.1f}s, {mb:.1f} MB, audio ok)")

def main():
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest="cmd", required=True)
    cache_default = str(Path.home() / ".cache/wwuai-reel")
    s = sp.add_parser("setup"); s.add_argument("--cache", default=cache_default)
    s = sp.add_parser("prepare"); s.add_argument("work"); s.add_argument("video")
    s = sp.add_parser("transcribe"); s.add_argument("work"); s.add_argument("--cache", default=cache_default)
    s.add_argument("--engine", default="auto", choices=["auto", "whisper", "vosk"])
    s.add_argument("--model", default="small.en"); s.add_argument("--names", default="")
    s = sp.add_parser("cut"); s.add_argument("work"); s.add_argument("--plan", action="store_true")
    s = sp.add_parser("storyboard"); s.add_argument("work")
    s = sp.add_parser("check-behind"); s.add_argument("work")
    s = sp.add_parser("samples"); s.add_argument("work")
    s = sp.add_parser("save-look"); s.add_argument("work"); s.add_argument("name"); s.add_argument("--default", action="store_true")
    s = sp.add_parser("use-look"); s.add_argument("work"); s.add_argument("name")
    s = sp.add_parser("list-looks")
    s = sp.add_parser("looks-sheet"); s.add_argument("work")
    s = sp.add_parser("preview"); s.add_argument("work")
    s = sp.add_parser("export"); s.add_argument("work"); s.add_argument("--out", default="")
    a = ap.parse_args()
    {"setup": setup, "prepare": prepare, "transcribe": transcribe, "cut": cut, "check-behind": check_behind, "samples": samples, "save-look": save_look, "use-look": use_look, "list-looks": list_looks, "looks-sheet": looks_sheet, "storyboard": storyboard,
     "preview": lambda a: export(a, preview=True), "export": export}[a.cmd](a)

if __name__ == "__main__":
    main()
