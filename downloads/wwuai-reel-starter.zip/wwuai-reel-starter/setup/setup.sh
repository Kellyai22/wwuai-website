#!/bin/bash
# WWUAI Reel Editor setup for Mac (also works on Linux).
# Installs everything into ~/wwuai-reel. No Homebrew, no admin password, no system changes.
# Safe to run again: it only fixes what is missing, then proves it can make a video.
set -u
KIT="$(cd "$(dirname "$0")/.." && pwd)"
HOME_DIR="${WWUAI_REEL_HOME:-$HOME/wwuai-reel}"
VENV="$HOME_DIR/.venv"
PY="$VENV/bin/python"
mkdir -p "$HOME_DIR/projects" "$HOME_DIR/finished"

ok()   { echo "OK   $1"; }
fail() { echo "FIX  $1"; echo "NOT READY"; exit 1; }

# 1. uv (a small tool that installs a private copy of Python, nothing system-wide)
UV="$(command -v uv || true)"
[ -z "$UV" ] && [ -x "$HOME/.local/bin/uv" ] && UV="$HOME/.local/bin/uv"
if [ -z "$UV" ]; then
  echo "installing uv (one time) ..."
  curl -LsSf https://astral.sh/uv/install.sh | env UV_NO_MODIFY_PATH=1 sh >/dev/null 2>&1 || true
  [ -x "$HOME/.local/bin/uv" ] && UV="$HOME/.local/bin/uv"
fi
[ -z "$UV" ] && fail "could not install uv. Check the internet connection, then run setup again."
ok "uv"

# 2. A private Python just for the reel editor
if [ ! -x "$PY" ]; then
  echo "setting up Python (one time, about a minute) ..."
  "$UV" venv --seed --quiet --python 3.12 "$VENV" >/dev/null 2>&1 || fail "could not set up Python. Run setup again."
fi
ok "python $("$PY" -c 'import sys;print(sys.version.split()[0])')"

# 3. Packages: pictures, speech recognition, and a bundled FFmpeg
if ! "$PY" -c "import PIL, faster_whisper, imageio_ffmpeg, vosk, rembg" >/dev/null 2>&1; then
  echo "installing packages (one time, a few minutes) ..."
  "$UV" pip install --quiet --python "$PY" pillow faster-whisper imageio-ffmpeg "rembg[cpu]" cffi requests tqdm websockets >/dev/null 2>&1 \
    || fail "could not install packages. Check the internet connection, then run setup again."
  "$UV" pip install --quiet --python "$PY" --no-deps vosk >/dev/null 2>&1 || true
fi
ok "packages"

# 4. Speech models: Whisper (main, most accurate) and a small backup model from npm
WH=0; BK=0
"$PY" -c 'from faster_whisper import WhisperModel; print("checking the speech model (first time downloads about 500 MB) ...", flush=True); WhisperModel("small.en", device="cpu", compute_type="int8")' >/dev/null 2>&1 && WH=1
if [ "$WH" = 1 ]; then ok "speech model (Whisper)"; else echo "note Whisper could not download; the backup model will be used"; fi
"$PY" "$KIT/scripts/reel.py" setup >/dev/null 2>&1 && BK=1 && ok "backup speech model"
if [ "$WH" = 0 ] && [ "$BK" = 0 ]; then fail "could not download a speech model. Check the internet connection, then run setup again."; fi

# 4b. Person cut-out model (for the big word behind your head), about 170 MB once
"$PY" -c 'from rembg import new_session; new_session("u2net_human_seg")' >/dev/null 2>&1 && ok "cut-out model" \
  || echo "note cut-out model could not download; reels will use the hook tablet instead of the big word"

# 5. Prove it: make a 3-second test video with sound, then render it with captions
T="$HOME_DIR/.selftest"; rm -rf "$T"; mkdir -p "$T"
FF="$("$PY" -c 'import shutil,imageio_ffmpeg;print(shutil.which("ffmpeg") or imageio_ffmpeg.get_ffmpeg_exe())')"
"$FF" -v error -y -f lavfi -i "color=c=0x8a7f74:s=720x1280:d=3" -f lavfi -i "sine=frequency=220:duration=3" \
  -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest "$T/test.mp4" || fail "FFmpeg could not make a test clip."
"$PY" "$KIT/scripts/reel.py" prepare "$T/work" "$T/test.mp4" >/dev/null || fail "could not prepare a test video."
echo '[{"text":"Ready","start":0.4,"end":0.9,"accent":true,"i":0},{"text":"to","start":1.0,"end":1.2,"accent":false,"i":1},{"text":"edit.","start":1.3,"end":1.8,"accent":false,"i":2}]' > "$T/work/words.json"
"$PY" - "$T/work/plan.json" <<'EOF'
import json,sys; p=json.load(open(sys.argv[1])); p["hook"]="Setup test"; p["hook_end"]=2; json.dump(p,open(sys.argv[1],"w"))
EOF
"$PY" "$KIT/scripts/reel.py" export "$T/work" >/dev/null || fail "could not render the test video."
ok "test render"
rm -rf "$T"
echo "READY"
