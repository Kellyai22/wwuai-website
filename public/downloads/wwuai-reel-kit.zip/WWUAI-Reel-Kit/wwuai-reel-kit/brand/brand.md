# My brand

Claude reads this file every time it builds a reel. Change any line to your own,
or just tell Claude "change my brand colours" and it will update this for you.

## Colours (three is plenty)
- Dark colour: #3A131B
- Accent colour: #DDA983
- Light colour: #FAF8F6

Dark is for text on light boxes and dark backgrounds. Accent is for the one word
that matters. Light is for boxes, cards and text over your video.

## Fonts (any Google Fonts name)
- Heading font: Playfair Display
- Body font: Plus Jakarta Sans

## Instagram follow card
- Name:
- Handle:
- Tagline:

Optional: put a square photo of yourself in this folder called avatar.jpg.
If there isn't one, Claude uses a frame from your video.
