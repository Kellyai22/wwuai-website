# Notices

The files in `templates/` are adapted from blocks in the HyperFrames registry
(https://github.com/heygen-com/hyperframes), used under the Apache License 2.0
(see `HyperFrames-Apache-2.0.txt`).

Changes made: resized from landscape (1920 x 1080) to upright (1080 x 1920),
repositioned for phone safe areas, colours replaced with placeholders filled
from your brand file, sample text replaced with placeholders, and some sizes,
timings and layering adjusted.

HyperFrames itself, ffmpeg and the speech model are downloaded during setup
from their own publishers under their own licences. Fonts load from Google Fonts.
