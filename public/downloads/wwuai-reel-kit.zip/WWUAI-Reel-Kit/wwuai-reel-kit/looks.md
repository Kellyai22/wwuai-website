# The menu: five hooks, five caption styles, six extras

Everything uses the colours and fonts in `brand/brand.md`. The word in `code` is what goes in `reel.json`.

## Hooks (the first three seconds)

| Name | `style` | What it looks like | Good for |
|---|---|---|---|
| Marker circle | `marker` | Your hook fades up and a hand-drawn circle rings your emphasis word. | Calm, clear openers with one key word |
| Typed prompt | `typed` | A light card types your line out with a blinking cursor. | "Say this", prompts, how-tos |
| Slam | `slam` | Big bold words slam in with a little shake; the last word is in your accent colour. | Strong claims, energy |
| Punch-in | `punch` | The video zooms into your face as a tilted box with your hook lands. | Stopping the scroll |
| Torn paper | `torn` | Your hook fills the screen on paper, then rips away to show you. | Curiosity, a reveal |

## Captions

| Name | `style` | What it looks like |
|---|---|---|
| Word highlight | `highlight` | Short lines; each word lights up in an accent box as you say it. |
| One big word | `big-word` | One big word at a time on your chest; key words in your accent colour. |
| Emoji pop | `emoji` | Bold outlined words that pop in, with an emoji on the words you choose. |
| Karaoke pill | `karaoke` | A light pill; words darken as you say them. |
| Editorial | `editorial` | Elegant, centred; your key words big and italic. |

## Extras (any, or none)

| Name | `type` | What it adds | Notes |
|---|---|---|---|
| Camcorder | `camcorder` | Blinking REC, battery, today's date and a running counter. | Whole video |
| Green screen | `greenscreen` | You on your dark brand colour with a soft accent glow. | Plain wall works best. Slow to make. |
| Listicle | `listicle` | Numbered points slide in on a light card at the top. | 2 to 5 points, at the moment you list them |
| Scrapbook freeze | `scrapbook` | A flash, the frame freezes and darkens, you pop out smaller and tilted for three seconds. | Pick a fun moment |
| Instagram follow card | `follow` | Your photo, name and handle with a Follow button that taps to Following. | Last 4.5 seconds, above your head |
| End card | `endcard` | Your call to action over your last frame, in your dark colour with the key word in your accent, then an optional save-and-follow card. | Matches what you say: comment a word, link in bio, DM a word, or save and follow |

Not in this free version: background music, b-roll, removing retakes, words behind your head, and other effects.
