#!/usr/bin/env node
// WWUAI Reel Kit helper. One script, same commands on Mac and Windows.
//
//   node reel.mjs setup                 install the tools (once)
//   node reel.mjs new <video> [name]    tidy the video, cut long pauses, transcribe
//   node reel.mjs build <reel folder>   turn reel.json into an editable project
//   node reel.mjs preview <reel folder> check it and save still frames to look at
//   node reel.mjs render <reel folder>  make the final MP4
//   node reel.mjs test                  setup check with a made-up clip
//
// Everything is installed into one folder in the user's home (.wwuai-reel-kit),
// with no admin rights. Reels are saved in a "Reels" folder in the user's home.

import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HF_VERSION = "0.8.217";
const KIT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const TOOLS = path.join(os.homedir(), ".wwuai-reel-kit");
const REELS = path.join(os.homedir(), "Reels");
const WIN = process.platform === "win32";
const W = 1080, H = 1920, FPS = 30;

// ---------- small helpers ----------
function die(msg) { console.error("\nSTOPPED: " + msg + "\n"); process.exit(1); }
function say(msg) { console.log(msg); }
function run(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { encoding: "utf8", maxBuffer: 1 << 28, env: toolEnv(), ...opts });
  if (r.error) die(`could not run ${path.basename(cmd)}: ${r.error.message}`);
  return r;
}
function mustRun(cmd, args, what, opts) {
  const r = run(cmd, args, opts);
  if (r.status !== 0) die(`${what} failed.\n${(r.stderr || r.stdout || "").slice(-2500)}`);
  return r;
}
function toolRequire() { return createRequire(path.join(TOOLS, "package.json")); }
function ffmpegPath() { try { return toolRequire()("ffmpeg-static"); } catch { return null; } }
function ffprobePath() { try { return toolRequire()("ffprobe-static").path; } catch { return null; } }
function hfBin() { return path.join(TOOLS, "node_modules", "hyperframes", "bin", "hyperframes.mjs"); }
function toolEnv() {
  const env = { ...process.env };
  // Put this Node (and its npm) first, so HyperFrames' own installs use it too.
  const pathKey = Object.keys(env).find((k) => k.toUpperCase() === "PATH") || "PATH";
  env[pathKey] = path.dirname(process.execPath) + path.delimiter + (env[pathKey] || "");
  const ff = ffmpegPath(), fp = ffprobePath();
  if (ff) { env.HYPERFRAMES_FFMPEG_PATH = ff; env[pathKey] = path.dirname(ff) + path.delimiter + env[pathKey]; }
  if (fp) env.HYPERFRAMES_FFPROBE_PATH = fp;
  return env;
}
function needTools() {
  if (!fs.existsSync(hfBin()) || !ffmpegPath() || !ffprobePath()) die("the tools aren't installed yet. Run: node reel.mjs setup");
}
function hf(args, cwd, what) { return mustRun(process.execPath, [hfBin(), ...args], what || "HyperFrames " + args[0], { cwd }); }
function ffmpeg(args, what) { return mustRun(ffmpegPath(), ["-hide_banner", "-loglevel", "error", "-y", ...args], what || "ffmpeg"); }
function duration(file) {
  const r = mustRun(ffprobePath(), ["-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", file], "reading the video length");
  return Math.round(parseFloat(r.stdout.trim()) * 100) / 100;
}
function slug(s) { return s.toLowerCase().replace(/\.[a-z0-9]+$/, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "reel"; }
function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function readJSON(f) { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) { die(`couldn't read ${f}: ${e.message}`); } }
function writeJSON(f, v) { fs.writeFileSync(f, JSON.stringify(v, null, 2), "utf8"); }
function reelDir(arg) {
  if (!arg) die("say which reel folder, for example: node reel.mjs build \"" + path.join(REELS, "my-reel") + "\"");
  const d = fs.existsSync(arg) ? path.resolve(arg) : path.join(REELS, arg);
  if (!fs.existsSync(path.join(d, "reel.json"))) die(`no reel.json in ${d}. Run "new" first.`);
  return d;
}
function openFolder(file) {
  if (WIN) spawnSync("explorer", ["/select,", file]);
  else if (process.platform === "darwin") spawnSync("open", ["-R", file]);
}

// ---------- brand ----------
function brand() {
  const f = path.join(KIT, "brand", "brand.md");
  const t = fs.existsSync(f) ? fs.readFileSync(f, "utf8") : "";
  const get = (label, dflt) => {
    const m = t.match(new RegExp("^[ \\t]*[-*]?[ \\t]*" + label + "[ \\t]*:[ \\t]*(\\S.*?)[ \\t]*$", "im"));
    return m ? m[1].replace(/[`*]/g, "").trim() : dflt;
  };
  const hex = (v, d) => (/^#[0-9a-f]{6}$/i.test(v) ? v : d);
  const avatar = ["avatar.jpg", "avatar.png", "avatar.jpeg"].map((n) => path.join(KIT, "brand", n)).find((p) => fs.existsSync(p));
  return {
    dark: hex(get("Dark colour", ""), "#1F1F1F"),
    accent: hex(get("Accent colour", ""), "#F2B84B"),
    light: hex(get("Light colour", ""), "#FFFFFF"),
    headFont: get("Heading font", "Playfair Display"),
    bodyFont: get("Body font", "Plus Jakarta Sans"),
    name: get("Name", ""),
    handle: get("Handle", ""),
    tagline: get("Tagline", ""),
    avatar,
  };
}

// ---------- setup ----------
function setup() {
  const major = parseInt(process.versions.node.split(".")[0], 10);
  if (major < 22) die(`Node ${process.versions.node} is too old. Install Node 22 or newer from nodejs.org, then run setup again.`);
  fs.mkdirSync(TOOLS, { recursive: true });
  const pkg = path.join(TOOLS, "package.json");
  if (!fs.existsSync(pkg)) writeJSON(pkg, { name: "wwuai-reel-kit-tools", private: true });
  say("1/4 Installing HyperFrames and ffmpeg into " + TOOLS + " (a few minutes the first time)...");
  // Use the npm that ships with this Node, so nothing else on the computer matters.
  const nodeDir = path.dirname(process.execPath);
  const npmCli = [path.join(nodeDir, "node_modules", "npm", "bin", "npm-cli.js"),
    path.join(nodeDir, "..", "lib", "node_modules", "npm", "bin", "npm-cli.js")].find((p) => fs.existsSync(p));
  if (!npmCli) die("can't find npm next to Node at " + nodeDir);
  mustRun(process.execPath, [npmCli, "install", "--no-audit", "--no-fund", `hyperframes@${HF_VERSION}`, "ffmpeg-static@5", "ffprobe-static@3"],
    "installing the tools", { cwd: TOOLS });
  if (!ffmpegPath() || !fs.existsSync(ffmpegPath())) die("ffmpeg didn't download. Check the internet connection and run setup again.");
  say("2/4 Downloading the speech-to-text model (about 650 MB)...");
  hf(["models", "install", "parakeet"], TOOLS, "downloading the speech model");
  say("3/4 Downloading the browser HyperFrames uses to draw frames...");
  hf(["browser", "ensure"], TOOLS, "downloading the render browser");
  say("4/4 Checking everything...");
  const r = run(process.execPath, [hfBin(), "doctor"], { cwd: TOOLS });
  say((r.stdout || "").split("\n").filter((l) => /FFmpeg|FFprobe|Chrome|Node/.test(l)).join("\n"));
  say("\nSETUP DONE. Next: node reel.mjs test");
}

// ---------- new: tidy, cut pauses, transcribe ----------
function findPauses(file) {
  const r = run(ffmpegPath(), ["-hide_banner", "-i", file, "-af", "silencedetect=noise=-30dB:d=0.7", "-f", "null", "-"]);
  const out = r.stderr || "";
  const starts = [...out.matchAll(/silence_start: ([\d.]+)/g)].map((m) => +m[1]);
  const ends = [...out.matchAll(/silence_end: ([\d.]+)/g)].map((m) => +m[1]);
  return starts.map((s, i) => [s, ends[i] ?? null]);
}
function keepRanges(total, pauses) {
  // Long pauses shrink to about half a second, so natural pauses stay.
  const keep = []; let cur = 0;
  for (const [s, e0] of pauses) {
    const e = e0 ?? total;
    if (s <= 0.05) { cur = Math.max(cur, e - 0.15); continue; }          // quiet start
    if (e >= total - 0.05) { keep.push([cur, Math.min(total, s + 0.3)]); cur = total; break; } // quiet end
    keep.push([cur, s + 0.25]); cur = e - 0.25;
  }
  if (cur < total) keep.push([cur, total]);
  return keep.filter(([a, b]) => b - a > 0.1).map(([a, b]) => [+a.toFixed(3), +b.toFixed(3)]);
}
function transcribe(video, dir) {
  const r = hf(["transcribe", video, "--dir", dir, "--engine", "parakeet", "--json"], dir, "transcribing");
  const line = (r.stdout || "").trim().split("\n").pop();
  let info = {}; try { info = JSON.parse(line); } catch {}
  const tp = info.transcriptPath || path.join(dir, "transcript.json");
  let words = [];
  if (fs.existsSync(tp)) {
    const t = readJSON(tp);
    words = (Array.isArray(t) ? t : t.words || t.segments || []).filter((w) => w && w.text != null)
      .map((w) => ({ text: String(w.text).trim(), start: +(+w.start).toFixed(2), end: +(+w.end).toFixed(2) })).filter((w) => w.text);
  }
  return words;
}
function cmdNew(src, name) {
  needTools();
  if (!src || !fs.existsSync(src)) die("can't find that video file: " + src);
  const nm = slug(name || path.basename(src)) + "-" + new Date().toISOString().slice(0, 10);
  const dir = path.join(REELS, nm);
  fs.mkdirSync(dir, { recursive: true });
  say("Reel folder: " + dir);
  const norm = path.join(dir, "upright.mp4");
  say("Making it upright 1080x1920...");
  // Raise the volume by one fixed amount to normal reel loudness, and only tame the few loudest peaks.
  // (An automatic leveller squashes the voice and makes it sound unnatural.)
  const meas = run(ffmpegPath(), ["-hide_banner", "-i", path.resolve(src), "-vn", "-af", "ebur128", "-f", "null", "-"]);
  const iMatch = [...(meas.stderr || "").matchAll(/I:\s+(-?[\d.]+) LUFS/g)].pop();
  const gain = iMatch ? Math.max(-10, Math.min(24, -16 - parseFloat(iMatch[1]))) : 0;
  ffmpeg(["-i", path.resolve(src), "-vf", `scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},fps=${FPS},format=yuv420p`,
    "-af", `volume=${gain.toFixed(1)}dB,alimiter=limit=0.84:attack=5:release=60:level=disabled`, "-b:a", "256k",
    "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-c:a", "aac", "-ar", "48000", "-ac", "2", norm], "making the video upright");
  const total = duration(norm);
  say("Finding long pauses...");
  const keep = keepRanges(total, findPauses(norm));
  const cut = path.join(dir, "cut.mp4");
  const kept = keep.reduce((n, [a, b]) => n + (b - a), 0);
  if (keep.length > 1 || total - kept > 0.3) {
    const sel = keep.map(([a, b]) => `between(t,${a},${b})`).join("+");
    ffmpeg(["-i", norm, "-vf", `select='${sel}',setpts=N/FRAME_RATE/TB`, "-af", `aselect='${sel}',asetpts=N/SR/TB`,
      "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", cut], "cutting the pauses");
  } else fs.copyFileSync(norm, cut);
  const dur = duration(cut);
  say(`Cut ${(total - dur).toFixed(1)}s of pauses. Reel is now ${dur.toFixed(1)}s.`);
  say("Transcribing (word by word)...");
  const words = transcribe(cut, dir);
  writeJSON(path.join(dir, "words.json"), words);
  fs.writeFileSync(path.join(dir, "transcript.txt"), words.map((w) => w.text).join(" "), "utf8");
  const rj = path.join(dir, "reel.json");
  if (!fs.existsSync(rj)) writeJSON(rj, {
    name: nm,
    hook: { style: "marker", text: "", emphasis: "", seconds: 3.5 },
    captions: { style: "highlight", emphasis: [], emoji: {} },
    extras: [],
  });
  say("\nREADY. Folder: " + dir + "\nLength: " + dur + "s\nTranscript: " + (words.map((w) => w.text).join(" ") || "(no speech found)"));
}

// ---------- caption data ----------
const STOP = new Set("the a an and or but is are was were to of in on at for with by from as it its this that these those be been have has had do does did will would could should may might must can if then so just not no yes up out about i you we they he she me my your our their them us im it's i'm you're don't".split(" "));
const clean = (t) => t.toLowerCase().replace(/[^a-z0-9']/g, "");
function groupWords(words, max = 3) {
  const groups = []; let g = [];
  words.forEach((w, i) => {
    g.push(i);
    const next = words[i + 1];
    const brk = g.length >= max || /[.?!,:;]$/.test(w.text) || (next && next.start - w.end > 0.35);
    if (brk || !next) { groups.push([g[0], g[g.length - 1]]); g = []; }
  });
  return groups;
}
function emphasisIdx(words, groups, chosen) {
  const want = new Set((chosen || []).map(clean));
  if (want.size) return words.map((w, i) => (want.has(clean(w.text)) ? i : -1)).filter((i) => i >= 0);
  const out = [];
  for (const [a, b] of groups) {
    let best = -1, len = 0;
    for (let i = a; i <= b; i++) { const c = clean(words[i].text); if (!STOP.has(c) && c.length > len && c.length >= 6) { best = i; len = c.length; } }
    if (best >= 0) out.push(best);
  }
  return out;
}
function blocks(words, groups, emph) {
  const E = new Set(emph);
  return groups.map(([a, b]) => {
    const idx = []; for (let i = a; i <= b; i++) idx.push(i);
    const k = idx.find((i) => E.has(i));
    if (k == null) return { line1: idx.map((i) => [i, "n"]), line2: null };
    const before = idx.filter((i) => i < k), after = idx.filter((i) => i > k);
    if (before.length) return { line1: before.map((i) => [i, "n"]), line2: [[k, "e"], ...after.map((i) => [i, "n"])] };
    return { line1: [[k, "e"]], line2: after.length ? after.map((i) => [i, "n"]) : null };
  });
}

// ---------- build ----------
const TPL = (p) => fs.readFileSync(path.join(KIT, "templates", p), "utf8");
function fill(s, map) { for (const [k, v] of Object.entries(map)) s = s.split(k).join(v); return s; }
function host(id, src, start, dur, track, opts = {}) {
  const w = opts.w || W, h = opts.h || H;
  const vars = opts.vars ? ` data-variable-values='${JSON.stringify(opts.vars).replace(/'/g, "&#39;")}'` : "";
  const style = opts.style || `position:absolute;left:0;top:0;width:${w}px;height:${h}px`;
  return `<div id="h-${id}" data-composition-id="${id}" data-composition-src="${src}" data-start="${start}" data-duration="${dur}" data-track-index="${track}" data-width="${w}" data-height="${h}"${vars} style="${style}"></div>`;
}
function fontLink(b) {
  const fam = [...new Set([b.headFont, b.bodyFont])].map((f) => "family=" + f.trim().replace(/ /g, "+") + ":ital,wght@0,500;0,700;0,800;1,700").join("&");
  return `<link href="https://fonts.googleapis.com/css2?${fam}&display=swap" rel="stylesheet">`;
}
function emphHTML(text, word, color, italic) {
  if (!word) return esc(text);
  const re = new RegExp("(" + word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", "i");
  return esc(text).replace(re, `<span style="color:${color}${italic ? ";font-style:italic" : ""}">$1</span>`);
}

function build(dir) {
  needTools();
  const reel = readJSON(path.join(dir, "reel.json"));
  const words = fs.existsSync(path.join(dir, "words.json")) ? readJSON(path.join(dir, "words.json")) : [];
  const b = brand();
  const cut = path.join(dir, "cut.mp4");
  if (!fs.existsSync(cut)) die("no cut.mp4 in the reel folder. Run \"new\" first.");
  const DUR = duration(cut);
  const proj = path.join(dir, "project");
  fs.rmSync(proj, { recursive: true, force: true });
  for (const d of ["compositions/components", "assets"]) fs.mkdirSync(path.join(proj, d), { recursive: true });
  fs.copyFileSync(cut, path.join(proj, "clip.mp4"));
  writeJSON(path.join(proj, "hyperframes.json"), { paths: { blocks: "compositions", components: "compositions/components", assets: "assets" } });
  writeJSON(path.join(proj, "package.json"), { name: "reel", private: true, type: "module" });

  const body = []; const js = []; let endHold = 0;
  const extras = reel.extras || [];
  const has = (t) => extras.find((e) => e.type === t);
  const font = (f) => `'${f}',sans-serif`;
  const colours = { __ACCENT__: b.accent, __LIGHT__: b.light, __DARK__: b.dark, __DUR__: String(DUR),
    __BODY_FONT__: b.bodyFont, __HEAD_FONT__: b.headFont, __BODY_FONT_URL__: b.bodyFont.trim().replace(/ /g, "+"), __HEAD_FONT_URL__: b.headFont.trim().replace(/ /g, "+") };

  // base video (or green screen)
  if (has("greenscreen")) {
    say("Cutting you out of the background for the green screen (this is the slow part, often a few minutes)...");
    hf(["remove-background", "clip.mp4", "-o", "person.webm"], proj, "removing the background");
    body.push(`<div id="bg" class="clip" data-start="0" data-duration="${DUR}" data-track-index="0" style="position:absolute;inset:0;background:radial-gradient(ellipse 70% 45% at 50% 62%, ${b.accent} 0%, transparent 70%), ${b.dark}"></div>`,
      `<video id="v" class="clip" src="person.webm" playsinline muted data-has-audio="false" data-start="0" data-duration="${DUR}" data-track-index="1" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover"></video>`,
      `<audio id="voice" class="clip" src="clip.mp4" data-start="0" data-duration="${DUR}" data-track-index="20"></audio>`);
  } else {
    body.push(`<video id="v" class="clip" src="clip.mp4" playsinline data-has-audio="true" data-start="0" data-duration="${DUR}" data-track-index="0" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover"></video>`);
  }

  // captions
  const cs = (reel.captions && reel.captions.style) || "none";
  const capFile = { highlight: "highlight", "big-word": "kinetic-slam", emoji: "emoji-pop", karaoke: "pill-karaoke", editorial: "editorial-emphasis" }[cs];
  if (capFile && words.length) {
    const groups = groupWords(words, cs === "karaoke" ? 4 : 3);
    const emph = emphasisIdx(words, groups, reel.captions.emphasis);
    const map = { ...colours, __WORDS__: JSON.stringify(words), __GROUPS__: JSON.stringify(groups),
      __KEY_INDEXES__: JSON.stringify(emph), __KEY_WORDS__: JSON.stringify(emph.map((i) => clean(words[i].text))),
      __EMOJI__: JSON.stringify(Object.fromEntries(Object.entries(reel.captions.emoji || {}).map(([k, v]) => [clean(k), v]))),
      __BLOCKS__: JSON.stringify(blocks(words, groups, emph)) };
    const id = "caption-" + capFile;
    fs.writeFileSync(path.join(proj, "compositions/components", id + ".html"), fill(TPL("captions/" + id + ".html"), map), "utf8");
    body.push(host(id, `compositions/components/${id}.html`, 0, DUR, 5));
  }

  // hook
  const hk = reel.hook || {};
  const HT = Math.min(+(hk.seconds || 3.5), Math.max(1, DUR - 0.3));
  const text = (hk.text || "").trim();
  const emw = (hk.emphasis || "").trim();
  const TOP = `position:absolute;left:0;top:200px;width:${W}px;height:560px;--bg:transparent;--brand:${b.accent};--fg:${b.light};--font-display:${font(b.bodyFont)}`;
  if (text) {
    if (hk.style === "marker") {
      fs.writeFileSync(path.join(proj, "compositions/components/marker-highlight.html"), TPL("hooks/marker-highlight.html"));
      body.push(host("marker-highlight", "compositions/components/marker-highlight.html", 0.2, HT, 6,
        { w: W, h: 560, style: TOP, vars: { text, emphasis_word: emw || text.split(/\s+/).pop().replace(/[^\w']/g, ""), style: "circle", accent: "green", exit: "fade" } }));
    } else if (hk.style === "slam") {
      fs.writeFileSync(path.join(proj, "compositions/components/headline-slam.html"), TPL("hooks/headline-slam.html"));
      body.push(host("headline-slam", "compositions/components/headline-slam.html", 0.2, HT, 6,
        { w: W, h: 560, style: TOP, vars: { text, accent_word_index: text.split(/\s+/).length - 1, accent: "green" } }));
    } else if (hk.style === "typed") {
      const label = hk.label ? `<div style="font-size:30px;color:${b.dark};opacity:.6;margin-bottom:18px;font-weight:500">${esc(hk.label)}</div>` : "";
      body.push(`<div id="twcard" class="clip" data-start="0.2" data-duration="${HT}" data-track-index="6" style="position:absolute;left:70px;top:260px;width:940px;padding:44px 48px;background:${b.light};border-radius:28px;box-shadow:0 20px 60px rgba(0,0,0,.35);font-family:${font(b.bodyFont)}">${label}`
        + `<div class="tw" style="display:inline-flex;align-items:center;gap:6px;font:800 ${text.length > 24 ? 50 : 64}px/1.15 ui-monospace,Menlo,Consolas,monospace;color:${b.dark}"><span style="display:inline-block;max-width:calc(var(--p,0)*100%);overflow:hidden;white-space:${text.length > 24 ? "normal" : "nowrap"}">${esc(text)}</span>`
        + `<i style="display:block;flex:none;width:6px;height:1em;background:${b.accent};border-radius:3px;opacity:var(--c,1)"></i></div></div>`);
      const typeT = Math.min(1.6, 0.05 * text.length + 0.4);
      js.push(`t.from("#twcard",{y:-40,opacity:0,duration:.35,ease:"power2.out"},0.2);t.fromTo(".tw",{"--p":0},{"--p":1,duration:${typeT},ease:"steps(${text.length})"},0.6);t.to(".tw i",{"--c":0.15,duration:.25,repeat:9,yoyo:true,ease:"none"},0.6);t.to("#twcard",{opacity:0,y:-30,duration:.3},${(0.2 + HT - 0.35).toFixed(2)});`);
    } else if (hk.style === "punch") {
      body.push(`<div id="pb" class="clip" data-start="0.2" data-duration="${HT}" data-track-index="6" style="position:absolute;left:0;right:0;top:230px;text-align:center">`
        + `<div style="display:inline-block;background:${b.light};color:${b.dark};font-family:${font(b.bodyFont)};font-weight:800;font-size:${text.length > 30 ? 72 : 88}px;line-height:1.08;padding:26px 40px;border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.35);max-width:960px">${emphHTML(text, emw, b.accent, false)}</div></div>`);
      js.push(`t.fromTo("#v",{scale:1},{scale:1.32,transformOrigin:"50% 38%",duration:.22,ease:"power3.out"},0.2);t.to("#v",{scale:1.12,duration:${(HT - 0.9).toFixed(2)},ease:"sine.inOut"},0.42);t.to("#v",{scale:1,duration:.3,ease:"power2.inOut"},${(0.2 + HT - 0.3).toFixed(2)});`
        + `t.fromTo("#pb > div",{scale:1.5,opacity:0,rotation:-3},{scale:1,opacity:1,rotation:-2,duration:.28,ease:"back.out(2.2)"},0.2);t.to("#pb",{opacity:0,duration:.25},${(0.2 + HT - 0.3).toFixed(2)});`);
    } else if (hk.style === "torn") {
      const paper = `<div style="position:absolute;inset:0;background:${b.light};display:flex;align-items:center;justify-content:center;text-align:center;padding:0 80px;color:${b.dark};font-family:'${b.headFont}',serif;font-weight:700;font-size:${text.length > 30 ? 118 : 136}px;line-height:1.05"><div>${emphHTML(text, emw, b.accent, true)}</div></div>`;
      const hold = Math.min(1.4, HT / 2);
      fs.writeFileSync(path.join(proj, "compositions/components/torn-paper-rip.html"), TPL("hooks/torn-paper-rip.html"));
      body.push(`<div id="paper0" class="clip" data-start="0" data-duration="${hold}" data-track-index="7" style="position:absolute;inset:0;z-index:50">${paper}</div>`,
        `<template data-slot="torn-paper-rip-from">${paper}</template><template data-slot="torn-paper-rip-to"><div></div></template>`,
        host("torn-paper-rip", "compositions/components/torn-paper-rip.html", hold, 1.4, 6, { vars: { direction: "left-to-right", tone: "white", roughness: 60 }, style: `position:absolute;inset:0;width:${W}px;height:${H}px;--bg:transparent;z-index:50` }));
    } else die(`hook style "${hk.style}" isn't one of: marker, typed, slam, punch, torn`);
  }

  // extras
  for (const ex of extras) {
    if (ex.type === "camcorder") {
      const d = new Date();
      const date = d.toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" }).replace(",", "").toUpperCase() + "<br />" + d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
      fs.writeFileSync(path.join(proj, "compositions/camcorder-hud.html"), fill(TPL("extras/camcorder-hud.html"), { ...colours, __DATE__: date }));
      body.push(host("camcorder-hud", "compositions/camcorder-hud.html", 0, DUR, 2));
    } else if (ex.type === "listicle") {
      const items = (ex.items || []).slice(0, 5);
      if (!items.length) die("the listicle needs items, for example \"items\": [[\"1. Film it upright\", \"Phone at eye level\"]]");
      const st = +(ex.start ?? 4), du = Math.min(+(ex.seconds ?? 6), DUR - st);
      const rows = items.map((r) => (Array.isArray(r) ? { label: r[0], value: r[1] || "" } : r));
      const cardH = rows.length * 118 + 70;
      fs.writeFileSync(path.join(proj, "compositions/mk-specs-list.html"), fill(TPL("extras/mk-specs-list.html"), { ...colours, __DUR__: String(du), __ROWS__: JSON.stringify(rows) }).replace(/font-family: var\(--mk-font\)/g, `font-family: ${font(b.bodyFont)}`));
      body.push(`<div id="card" class="clip" data-start="${st + 0.1}" data-duration="${(du - 0.4).toFixed(2)}" data-track-index="3" style="position:absolute;left:50px;top:190px;width:980px;height:${cardH}px;background:${b.light};opacity:.94;border-radius:22px"></div>`,
        host("mk-specs-list", "compositions/mk-specs-list.html", st, du, 4));
    } else if (ex.type === "scrapbook") {
      const at = Math.min(+(ex.at ?? DUR / 2), DUR - 3.2);
      ffmpeg(["-ss", String(at), "-i", path.join(proj, "clip.mp4"), "-frames:v", "1", path.join(proj, "still.png")], "grabbing the freeze frame");
      say("Cutting you out of the frozen frame...");
      hf(["remove-background", "still.png", "-o", "cut.png"], proj, "cutting out the freeze frame");
      fs.writeFileSync(path.join(proj, "compositions/freeze-frame-dressing.html"), TPL("extras/freeze-frame-dressing.html"));
      body.push(`<img id="frz" class="clip" src="still.png" data-start="${at}" data-duration="3" data-track-index="10" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover" />`,
        host("freeze-frame-dressing", "compositions/freeze-frame-dressing.html", at, 3, 11),
        `<img id="cut" class="clip" src="cut.png" data-start="${(at + 0.06).toFixed(2)}" data-duration="2.94" data-track-index="12" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transform-origin:50% 45%;filter:drop-shadow(10px 0 0 #fff) drop-shadow(-10px 0 0 #fff) drop-shadow(0 10px 0 #fff) drop-shadow(0 -10px 0 #fff) drop-shadow(0 26px 30px rgba(0,0,0,.45))" />`);
      js.push(`t.fromTo("#frz",{filter:"brightness(1) saturate(1)"},{filter:"brightness(.62) saturate(.5)",duration:.3,ease:"power2.out"},${at});t.fromTo("#cut",{scale:1,rotation:0,y:0},{scale:.7,rotation:-7,y:-60,duration:.5,ease:"back.out(1.7)"},${(at + 0.12).toFixed(2)});t.to("#cut",{rotation:-5,duration:2.2,ease:"sine.inOut"},${(at + 0.62).toFixed(2)});`);
    } else if (ex.type === "follow") {
      const name = ex.name || b.name, handle = ex.handle || b.handle, tag = ex.tagline ?? b.tagline;
      if (!name || !handle) die("the follow card needs a Name and Handle. Add them to brand/brand.md.");
      const st = Math.max(0, +(ex.start ?? DUR - 4.5));
      const av = path.join(proj, "assets", "avatar.jpg");
      if (b.avatar) ffmpeg(["-i", b.avatar, "-vf", "scale=320:320:force_original_aspect_ratio=increase,crop=320:320", av], "preparing the profile photo");
      else ffmpeg(["-ss", "1", "-i", path.join(proj, "clip.mp4"), "-frames:v", "1", "-vf", "crop=640:640:220:280,scale=320:320", av], "making a profile photo from the video");
      fs.writeFileSync(path.join(proj, "compositions/instagram-follow.html"), fill(TPL("extras/instagram-follow.html"), { __NAME__: esc(name), __HANDLE__: esc(handle), __TAGLINE__: esc(tag || "") }));
      body.push(host("instagram-follow", "compositions/instagram-follow.html", st, Math.min(4.5, DUR - st), 8));
    } else if (ex.type === "endcard") {
      // A call to action over the last frame, in the brand's dark colour. Up to two cards:
      // the call to action (comment / link / dm / follow) and an optional save-and-follow sign-off.
      const cta = ex.cta || {};
      const presets = {
        comment: { lead: "Comment", big: cta.word || "", after: cta.after ?? "and it'll come straight to your DMs" },
        link: { lead: cta.lead || "Grab it at the", big: cta.word || "link in my bio", after: cta.after ?? "" },
        dm: { lead: "Send me", big: cta.word || "", after: cta.after ?? "in a DM" },
        follow: { lead: "And don't forget to", big: "save this", after: cta.after ?? "and follow for more" },
      };
      const cards = [];
      if (cta.kind) { if (!presets[cta.kind]) die('endcard "cta.kind" must be comment, link, dm or follow'); cards.push({ ...presets[cta.kind], ...(cta.lead ? { lead: cta.lead } : {}) }); }
      if (ex.signoff) cards.push(typeof ex.signoff !== "object" ? { lead: "And don't forget to", big: "save this", after: "and follow for more" } : { lead: ex.signoff.lead ?? "And don't forget to", big: ex.signoff.big ?? "save this", after: ex.signoff.after ?? "and follow for more" });
      if (!cards.length) die("the end card needs a cta (kind: comment, link, dm or follow) and/or signoff: true");
      endHold = Math.max(1.5, +(ex.seconds ?? 2.4 * cards.length));
      const first = ex.at != null ? Math.min(+ex.at, DUR - 0.5) : DUR;
      const label = esc(ex.label ?? (b.handle || b.name || ""));
      const T = DUR + endHold;
      const span = (T - first) / cards.length;
      ffmpeg(["-sseof", "-0.1", "-i", path.join(proj, "clip.mp4"), "-frames:v", "1", "-update", "1", path.join(proj, "assets", "last.jpg")], "grabbing the last frame");
      body.push(`<img id="lastframe" class="clip" src="assets/last.jpg" data-start="${DUR}" data-duration="${endHold}" data-track-index="13" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover" />`);
      cards.forEach((c, i) => {
        const st = +(first + i * span).toFixed(2), du = +(T - st - (i < cards.length - 1 ? T - (first + (i + 1) * span) : 0)).toFixed(2);
        body.push(`<div id="ec${i}" class="clip" data-start="${st}" data-duration="${du}" data-track-index="${14 + i}" style="position:absolute;inset:0;z-index:60;background:color-mix(in srgb, ${b.dark} 78%, transparent);color:${b.light};display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:0 110px;font-family:${font(b.bodyFont)}">`
          + (c.lead ? `<div style="font-size:84px;line-height:1.05;font-weight:500">${esc(c.lead)}</div>` : "")
          + (c.big ? `<div style="font-family:'${b.headFont}',serif;font-style:italic;font-weight:700;font-size:${c.big.length > 12 ? 112 : 150}px;line-height:1.05;color:${b.accent};margin:6px 0">${esc(c.big)}</div>` : "")
          + (c.after ? `<div style="font-size:60px;line-height:1.18;margin-top:14px">${esc(c.after)}</div>` : "")
          + (label ? `<div style="font-size:30px;letter-spacing:5px;margin-top:70px;color:${b.accent}">${label}</div>` : "")
          + "</div>");
        js.push(`t.from("#ec${i}",{opacity:0,duration:.45,ease:"power1.inOut"},${st});`);
      });
    } else if (ex.type !== "greenscreen") die(`extra "${ex.type}" isn't one of: camcorder, greenscreen, listicle, scrapbook, follow, endcard`);
  }

  const html = `<!doctype html><html lang="en"><head><meta charset="UTF-8" /><meta name="viewport" content="width=${W}, height=${H}" />
${fontLink(b)}
<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
<style>*{margin:0;padding:0;box-sizing:border-box}html,body{width:${W}px;height:${H}px;overflow:hidden;background:#000}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="${(DUR + endHold).toFixed(2)}" data-width="${W}" data-height="${H}">
${body.join("\n")}
</div><script>window.__timelines=window.__timelines||{};var t=gsap.timeline({paused:true});
${js.join("\n")}
t.to({}, {duration:${(DUR + endHold).toFixed(2)}}, 0);window.__timelines["main"]=t;</script></body></html>`;
  fs.writeFileSync(path.join(proj, "index.html"), html, "utf8");
  say("BUILT: " + proj + "\nNext: node reel.mjs preview \"" + dir + "\"");
}

function preview(dir) {
  needTools();
  const proj = path.join(dir, "project");
  if (!fs.existsSync(path.join(proj, "index.html"))) die("build it first: node reel.mjs build \"" + dir + "\"");
  // Fonts load from the internet, so a network blip can fail the check. Retry once,
  // and only stop for problems that aren't a font download.
  let chk = run(process.execPath, [hfBin(), "check"], { cwd: proj });
  if (chk.status !== 0) chk = run(process.execPath, [hfBin(), "check"], { cwd: proj });
  if (chk.status !== 0) {
    const lines = (chk.stdout + chk.stderr).split("\n").filter((l) => /✗/.test(l));
    const real = lines.filter((l) => !/request_failed|fonts\.g|woff|need 3:1/i.test(l));
    if (real.length) die("the project has a problem:\n" + real.join("\n"));
    say("Note: some fonts didn't download during the check (internet blip). Carrying on; the render loads them again.");
  }
  const DUR = duration(path.join(proj, "clip.mp4"));
  const reel = readJSON(path.join(dir, "reel.json"));
  const times = [1.0, 2.2, DUR * 0.5, Math.max(0, DUR - 2.5)];
  for (const ex of reel.extras || []) if (ex.type === "scrapbook") times.push(+(ex.at ?? DUR / 2) + 1.2);
  for (const ex of reel.extras || []) if (ex.type === "endcard") { times.push(DUR + 0.8); times.push(DUR + 3.5); }
  const at = [...new Set(times.map((x) => +x.toFixed(1)))].join(",");
  const r = hf(["snapshot", "--at", at], proj, "taking preview frames");
  const outDir = path.join(dir, "preview");
  fs.rmSync(outDir, { recursive: true, force: true }); fs.mkdirSync(outDir);
  const pngs = [...(r.stdout + r.stderr).matchAll(/(\S+frame-\d+-at-[\d.]+s\.png)/g)].map((m) => m[1]);
  for (const p of pngs) if (fs.existsSync(p)) fs.copyFileSync(p, path.join(outDir, path.basename(p)));
  say("PREVIEW FRAMES (look at these before rendering):\n" + fs.readdirSync(outDir).map((f) => path.join(outDir, f)).join("\n"));
}

function render(dir, draft) {
  needTools();
  const proj = path.join(dir, "project");
  if (!fs.existsSync(path.join(proj, "index.html"))) die("build it first.");
  const reel = readJSON(path.join(dir, "reel.json"));
  let n = 1, out;
  do { out = path.join(dir, `${reel.name || "reel"}${draft ? "-draft" : ""}-v${n}.mp4`); n++; } while (fs.existsSync(out));
  say("Rendering " + (draft ? "a quick draft" : "the final reel") + " (a few minutes)...");
  hf(["render", "--output", out, ...(draft ? ["--quality", "draft"] : [])], proj, "rendering");
  if (!fs.existsSync(out)) die("the render finished but no video was saved.");
  say("DONE: " + out);
  openFolder(out);
}

function selfTest() {
  needTools();
  const src = path.join(TOOLS, "test-clip.mp4");
  ffmpeg(["-f", "lavfi", "-i", `testsrc2=size=${W}x${H}:rate=${FPS}:duration=5`, "-f", "lavfi", "-i", "sine=frequency=330:duration=5",
    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", src], "making a test clip");
  const dir = path.join(REELS, "setup-test");
  fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
  ffmpeg(["-i", src, "-c", "copy", path.join(dir, "cut.mp4")], "copying the test clip");
  writeJSON(path.join(dir, "words.json"), []);
  writeJSON(path.join(dir, "reel.json"), { name: "setup-test", hook: { style: "typed", text: "it works", seconds: 3 }, captions: { style: "none" }, extras: [{ type: "camcorder" }] });
  build(dir); render(dir, true);
  say("\nTEST PASSED. You're ready to make a reel.");
}

const [cmd, a, b2] = process.argv.slice(2);
if (cmd === "setup") setup();
else if (cmd === "new") cmdNew(a, b2);
else if (cmd === "build") build(reelDir(a));
else if (cmd === "preview") preview(reelDir(a));
else if (cmd === "render") render(reelDir(a), b2 === "--draft");
else if (cmd === "test") selfTest();
else say("Commands: setup | test | new <video> [name] | build <reel> | preview <reel> | render <reel> [--draft]");
