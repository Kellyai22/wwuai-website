# My reel rules

Claude reads these before every reel. Say "remember this" or "from now on" and Claude adds a line here. You can also edit this file yourself.

- Keep my natural pauses. Only shorten the long ones.
- My hook is short: eight words or fewer.
- Captions sit on my chest, never over my face.
- Use my brand colours from my brand file, nothing else.
- Show me the preview frames before making the final video.
