# For Claude: installing the WWUAI Reel Kit

The person has opened this folder in the Claude app and asked you to install the skill. They're new to AI, so keep every message short and friendly, and don't show them code.

1. Copy the `wwuai-reel-kit` folder (the one next to this file) into their skills folder, replacing any older copy:
   - Mac: `mkdir -p ~/.claude/skills && rm -rf ~/.claude/skills/wwuai-reel-kit && cp -R "./wwuai-reel-kit" ~/.claude/skills/`
   - Windows (PowerShell): `New-Item -ItemType Directory -Force "$env:USERPROFILE\.claude\skills" | Out-Null; Remove-Item -Recurse -Force "$env:USERPROFILE\.claude\skills\wwuai-reel-kit" -ErrorAction SilentlyContinue; Copy-Item -Recurse ".\wwuai-reel-kit" "$env:USERPROFILE\.claude\skills\"`
   If an older copy is already there, it holds their own settings: copy its `my-reel-rules.md` and `brand` folder somewhere safe first, and put them back over the new copy afterwards.
2. Read the installed `SKILL.md` and follow its "First time: set up" section, all five steps, in this session.
3. When the test has passed and their brand is saved, tell them: "All set. Start a new session in the Code tab, then say: edit my latest video."
